import scipy.io as sio, numpy as np, glob, os
EXP='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/Agentes/paired_reference/stage1/export/'
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
TEST=['MATEO','SANDRA']
SEED=20260904; EPS=1e-8; NB=10

def load_raw():
    S={}
    for f in sorted(glob.glob(EXP+'*_stage1.mat')):
        s=os.path.basename(f).replace('_stage1.mat','')
        m=sio.loadmat(f)
        rec=m['recordIdx'].ravel().astype(int); col=m['columnIdx'].ravel().astype(int)
        st=m['stepIdx'].ravel().astype(int); sie=m['stepsInEpisode'].ravel().astype(int)
        epi=rec*10+col
        o=np.lexsort((st,epi))
        S[s]=dict(X=m['X'].astype(float)[o], Y=m['Y'].astype(float)[o], epi=epi[o],
                  g=col[o], step=st[o], L=sie[o], phase=((st-1)/np.maximum(sie-1,1))[o])
    return S

def pairs(d, k, keep=None):
    """(phi_t, y_{t+k}) por episodio; keep = set de episodios a conservar."""
    X,Y,G,P,E,ST=[],[],[],[],[],[]
    bnds=np.flatnonzero(np.diff(d['epi']))+1
    for a,b in zip(np.r_[0,bnds], np.r_[bnds,len(d['epi'])]):
        e=d['epi'][a]
        if keep is not None and e not in keep: continue
        L=b-a
        for t in range(L):
            tt=t+k
            if tt<0 or tt>=L: continue
            X.append(d['X'][a+t]); Y.append(d['Y'][a+tt]); G.append(d['g'][a+t])
            P.append(d['phase'][a+t]); E.append(e); ST.append(t)
    return dict(X=np.array(X).reshape(-1,40), Y=np.array(Y).reshape(-1,4),
                g=np.array(G), phase=np.array(P), ep=np.array(E), step=np.array(ST))

def halves(S, subj):
    eps=np.unique(S[subj]['epi'])
    r=np.random.default_rng(SEED + sum(map(ord,subj)))
    p=eps.copy(); r.shuffle(p); n=len(p)//2
    return set(p[:n].tolist()), set(p[n:].tolist())

def cal_eps(S, subj, N, pool):
    d=S[subj]; out=[]
    for gg in [1,2]:
        cand=sorted({int(e) for e in pool if d['g'][d['epi']==e][0]==gg})
        out+=cand[:N]
    return set(out)

def subj_stats(S, subj, epset):
    d=S[subj]; m=np.isin(d['epi'], list(epset))
    X=d['X'][m]
    return X.mean(0), X.std(0,ddof=1)

def gram(X,Y):
    mx=X.mean(0); my=Y.mean(0); Xc=X-mx; Yc=Y-my
    return Xc.T@Xc, Xc.T@Yc, mx, my

def solve(A,B,mx,my,lam):
    W=np.linalg.solve(A+lam*np.eye(A.shape[0]), B)
    return W, my-mx@W

def mse(a,b): return float(np.mean((a-b)**2))
def mae(a,b): return float(np.mean(np.abs(a-b)))

def sign_acc(pred,true,ep,step):
    o=np.lexsort((step,ep)); p=pred[o]; t=true[o]; e=ep[o]
    same=np.diff(e)==0
    dp=np.diff(p,axis=0)[same]; dt=np.diff(t,axis=0)[same]
    m=np.abs(dt)>1e-9
    return float((np.sign(dp[m])==np.sign(dt[m])).sum()/max(m.sum(),1)), int(m.sum())

def phase_table(dtr):
    b=np.minimum((dtr['phase']*NB).astype(int),NB-1)
    return {(gg,bb): (dtr['Y'][(dtr['g']==gg)&(b==bb)].mean(0) if ((dtr['g']==gg)&(b==bb)).sum() else dtr['Y'].mean(0))
            for gg in [1,2] for bb in range(NB)}

def phase_pred(tbl,d):
    b=np.minimum((d['phase']*NB).astype(int),NB-1)
    return np.array([tbl[(g,bb)] for g,bb in zip(d['g'],b)])
