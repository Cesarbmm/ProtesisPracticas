import numpy as np, sys, json, time
sys.path.insert(0,'.')
from e1b_lib import *

KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19); BUDGETS=[2,5,10,20]
S=load_raw()
H={s:halves(S,s) for s in DEV}
t0=time.time()
P={(s,k):pairs(S[s],k) for s in DEV for k in KS}
print(f"pares precomputados en {time.time()-t0:.1f}s")

def sub(d,keep):
    m=np.isin(d['ep'],list(keep))
    return {kk:(v[m] if isinstance(v,np.ndarray) else v) for kk,v in d.items()}

CAL={(s,N):cal_eps(S,s,N,H[s][0]) for s in DEV for N in BUDGETS}
ST={(s,N):subj_stats(S,s,CAL[(s,N)]) for s in DEV for N in BUDGETS}

# grid[arm][fold][k][budget][lam] = mse
gridA=np.zeros((len(DEV),len(KS),len(LAMS)))
gridB=np.zeros((len(DEV),len(KS),len(BUDGETS),len(LAMS)))
mseC=np.zeros((len(DEV),len(KS)))
mseD=np.zeros((len(DEV),len(KS)))

t0=time.time()
for fi,Sout in enumerate(DEV):
    ev=H[Sout][1]
    tr_subj=[t for t in DEV if t!=Sout]
    for ki,k in enumerate(KS):
        de=sub(P[(Sout,k)],ev)
        Xtr=np.vstack([P[(t,k)]['X'] for t in tr_subj]); Ytr=np.vstack([P[(t,k)]['Y'] for t in tr_subj])
        dtr_all={kk:np.concatenate([P[(t,k)][kk] for t in tr_subj]) for kk in ['g','phase']}
        dtr_all['Y']=Ytr
        # C: media de train ; D: tabla gesto+fase
        mseC[fi,ki]=mse(np.repeat(Ytr.mean(0)[None,:],len(de['Y']),0), de['Y'])
        mseD[fi,ki]=mse(phase_pred(phase_table(dtr_all),de), de['Y'])
        # A: sin normalizacion por sujeto
        A,B,mx,my=gram(Xtr,Ytr)
        for li,lam in enumerate(LAMS):
            W,b=solve(A,B,mx,my,lam)
            gridA[fi,ki,li]=mse(de['X']@W+b, de['Y'])
        # B: con normalizacion subject-specific EMG-only
        for bi,N in enumerate(BUDGETS):
            Zs=[]
            for t in tr_subj:
                mu,sd=ST[(t,N)]
                Zs.append((P[(t,k)]['X']-mu)/(sd+EPS))
            Ztr=np.vstack(Zs)
            muS,sdS=ST[(Sout,N)]
            Zev=(de['X']-muS)/(sdS+EPS)
            A2,B2,mx2,my2=gram(Ztr,Ytr)
            for li,lam in enumerate(LAMS):
                W,b=solve(A2,B2,mx2,my2,lam)
                gridB[fi,ki,bi,li]=mse(Zev@W+b, de['Y'])
    print(f"  fold {Sout:10s} listo  ({time.time()-t0:.0f}s)")

np.savez('e1b_grid.npz',gridA=gridA,gridB=gridB,mseC=mseC,mseD=mseD,KS=KS,LAMS=LAMS,BUDGETS=BUDGETS,DEV=DEV)
print("\n=== CV OPTIMISTA (mejor config por MSE medio de los 10 folds) ===")
mA=gridA.mean(0); iA=np.unravel_index(np.argmin(mA),mA.shape)
mB=gridB.mean(0); iB=np.unravel_index(np.argmin(mB),mB.shape)
print(f"  A sin calibrar : k={KS[iA[0]]:+d} lambda={LAMS[iA[1]]:.4g}  MSE={mA[iA]:.6f}")
print(f"  B calibrado    : k={KS[iB[0]]:+d} lambda={LAMS[iB[2]]:.4g} N={BUDGETS[iB[1]]}  MSE={mB[iB]:.6f}")
print(f"  C media train  : MSE={mseC.mean(0).min():.6f}  (mejor k)")
print(f"  D gesto+fase   : MSE={mseD.mean(0).min():.6f}  (mejor k, DIAGNOSTIC_ORACLE)")
print(f"  mejora B vs A  : {100*(mA[iA]-mB[iB])/mA[iA]:+.1f}%")

print("\n=== CV ANIDADA (config elegida sin el fold en el que se reporta) ===")
def nested(grid):
    out=[]; cfg=[]
    for f in range(grid.shape[0]):
        others=np.delete(grid,f,axis=0).mean(0)
        i=np.unravel_index(np.argmin(others),others.shape)
        out.append(grid[(f,)+i]); cfg.append(i)
    return np.array(out),cfg
nA,cA=nested(gridA); nB,cB=nested(gridB)
print(f"  A sin calibrar : MSE={nA.mean():.6f}  (sd entre folds {nA.std():.6f})")
print(f"  B calibrado    : MSE={nB.mean():.6f}  (sd entre folds {nB.std():.6f})")
print(f"  mejora B vs A  : {100*(nA.mean()-nB.mean())/nA.mean():+.1f}%")
print(f"  presupuestos elegidos por fold: {[BUDGETS[c[1]] for c in cB]}")
print(f"  k elegidos por fold           : {[KS[c[0]] for c in cB]}")
np.savez('e1b_nested.npz',nA=nA,nB=nB,cA=cA,cB=cB)
