import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
BLUE,ORANGE,AQUA='#2a78d6','#eb6834','#1baf7a'
SURF='#fcfcfb';INK='#26251f';INK2='#5c5a50';GRID='#e3e2dc'
plt.rcParams.update({'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,
 'axes.edgecolor':GRID,'axes.labelcolor':INK2,'text.color':INK,'xtick.color':INK2,'ytick.color':INK2,
 'font.size':9,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'axes.spines.top':False,
 'axes.spines.right':False,'legend.frameon':False,'axes.axisbelow':True})
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
d=np.load('e1b_detail.npz'); R=d['rows']; sg=d['shufG'].mean(); sc=d['shufC'].mean()
fig,ax=plt.subplots(1,3,figsize=(13,4.2),gridspec_kw={'width_ratios':[2.1,1,1]})
x=np.arange(10); w=0.27
ax[0].bar(x-w,R[:,0],w,color=BLUE,label='A sin calibrar')
ax[0].bar(x  ,R[:,1],w,color=ORANGE,label='B calibrado EMG-only')
ax[0].bar(x+w,R[:,3],w,color=AQUA,label='D gesto+fase (oraculo)')
ax[0].set_xticks(x); ax[0].set_xticklabels(DEV,rotation=45,ha='right',fontsize=7.5)
ax[0].set_ylabel('MSE'); ax[0].set_title('MSE por sujeto dejado fuera (LOSO, 10 folds)',color=INK,fontsize=10)
ax[0].legend(fontsize=8,ncol=3)
N=[2,5,10,20]; secs=[12.2,30.5,61.0,122.0]; vsA=[0.6,-0.0,1.7,2.3]
ax[1].plot(secs,vsA,color=ORANGE,lw=2,marker='o',ms=7)
ax[1].axhline(15,color=INK2,lw=1.2,ls='--')
ax[1].text(secs[0],15.7,'umbral preregistrado 15%',fontsize=7.5,color=INK2)
ax[1].set_ylim(-2,18); ax[1].set_xlabel('EMG de calibracion (s)')
ax[1].set_ylabel('mejora de MSE sobre A (%)')
ax[1].set_title('Curva de presupuesto',color=INK,fontsize=10)
lab=['shuffle\nglobal','shuffle\ncondicionado']; val=[100*(sg-R[:,1].mean())/R[:,1].mean(),100*(sc-R[:,1].mean())/R[:,1].mean()]
ax[2].bar([0,1],val,0.5,color=[BLUE,ORANGE])
ax[2].axhline(15,color=INK2,lw=1.2,ls='--'); ax[2].axhline(5,color=INK2,lw=1,ls=':')
ax[2].text(1.48,15.2,'umbral global 15%',fontsize=7.5,color=INK2,ha='right',va='bottom')
ax[2].text(1.48,5.2,'umbral condicionado 5%',fontsize=7.5,color=INK2,ha='right',va='bottom')
ax[2].set_xlim(-0.6,1.6)
ax[2].set_xticks([0,1]); ax[2].set_xticklabels(lab,fontsize=8); ax[2].set_ylim(0,18)
ax[2].set_ylabel('degradacion del MSE (%)'); ax[2].set_title('Permutaciones sobre B',color=INK,fontsize=10)
fig.suptitle('E1B · la calibracion EMG-only no recupera la transferencia entre sujetos',color=INK,fontsize=12)
fig.tight_layout(rect=[0,0,1,0.93]); fig.savefig('E1B_resumen.png',dpi=150)
print("ok")
