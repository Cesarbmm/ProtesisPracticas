import numpy as np, sys
sys.path.insert(0,'.')
from e1b_lib import *
from scipy.stats import pearsonr
KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19); BUDGETS=[2,5,10,20]
g=np.load('e1b_grid.npz',allow_pickle=True)
gridA,gridB,mseC,mseD=g['gridA'],g['gridB'],g['mseC'],g['mseD']

print("=== curva por presupuesto (CV optimista, k y lambda optimos por presupuesto) ===")
print(f"{'N':>3s} {'seg EMG':>8s} {'MSE B':>10s} {'vs A':>8s} {'vs media':>9s}")
mA=gridA.mean(0); bestA=mA.min()
mB=gridB.mean(0); mC=mseC.mean(0).min()
for bi,N in enumerate(BUDGETS):
    v=mB[:,bi,:].min()
    print(f"{N:3d} {2*N*3.05:8.1f} {v:10.6f} {100*(bestA-v)/bestA:+7.1f}% {100*(mC-v)/mC:+8.1f}%")

K,LAM,NB_=2,1e6,20
ki=KS.index(K); li=int(np.argmin(np.abs(LAMS-LAM))); bi=BUDGETS.index(NB_)
print(f"\n=== configuracion seleccionada: k={K:+d}, lambda={LAMS[li]:.4g}, N={NB_} ===")

S=load_raw(); H={s:halves(S,s) for s in DEV}
P={(s,K):pairs(S[s],K) for s in DEV}
CAL={(s,NB_):cal_eps(S,s,NB_,H[s][0]) for s in DEV}
ST={(s,NB_):subj_stats(S,s,CAL[(s,NB_)]) for s in DEV}
def sub(d,keep):
    m=np.isin(d['ep'],list(keep)); return {kk:v[m] for kk,v in d.items()}

rows=[]; PA_all=[];PB_all=[];Y_all=[];EP_all=[];STP_all=[];G_all=[];PD_all=[]
shufG=[];shufC=[]
rng=np.random.default_rng(20260904)
for Sout in DEV:
    ev=H[Sout][1]; tr=[t for t in DEV if t!=Sout]
    de=sub(P[(Sout,K)],ev)
    Xtr=np.vstack([P[(t,K)]['X'] for t in tr]); Ytr=np.vstack([P[(t,K)]['Y'] for t in tr])
    dtr={kk:np.concatenate([P[(t,K)][kk] for t in tr]) for kk in ['g','phase']}; dtr['Y']=Ytr
    A_,B_,mx,my=gram(Xtr,Ytr); W,b=solve(A_,B_,mx,my,LAMS[li]); pA=de['X']@W+b
    Ztr=np.vstack([(P[(t,K)]['X']-ST[(t,NB_)][0])/(ST[(t,NB_)][1]+EPS) for t in tr])
    muS,sdS=ST[(Sout,NB_)]; Zev=(de['X']-muS)/(sdS+EPS)
    A2,B2,mx2,my2=gram(Ztr,Ytr); W2,b2=solve(A2,B2,mx2,my2,LAMS[li]); pB=Zev@W2+b2
    pC=np.repeat(Ytr.mean(0)[None,:],len(de['Y']),0); pD=phase_pred(phase_table(dtr),de)
    rows.append((Sout,mse(pA,de['Y']),mse(pB,de['Y']),mse(pC,de['Y']),mse(pD,de['Y'])))
    PA_all.append(pA);PB_all.append(pB);PD_all.append(pD);Y_all.append(de['Y'])
    EP_all.append(de['ep']+hash(Sout)%100000);STP_all.append(de['step']);G_all.append(de['g'])
    # permutaciones sobre el entrenamiento ya normalizado
    gg=[];cc=[]
    for sd in range(3):
        r=np.random.default_rng(500+sd)
        idx=np.arange(len(Ztr)); r.shuffle(idx)
        A3,B3,m3,y3=gram(Ztr[idx],Ytr); W3,b3=solve(A3,B3,m3,y3,LAMS[li]); gg.append(mse(Zev@W3+b3,de['Y']))
        Zc=Ztr.copy(); bph=np.minimum((dtr['phase']*NB).astype(int),NB-1)
        for q in [1,2]:
            for bb in range(NB):
                m=np.flatnonzero((dtr['g']==q)&(bph==bb))
                if len(m)>1:
                    pp=m.copy(); r.shuffle(pp); Zc[m]=Ztr[pp]
        A4,B4,m4,y4=gram(Zc,Ytr); W4,b4=solve(A4,B4,m4,y4,LAMS[li]); cc.append(mse(Zev@W4+b4,de['Y']))
    shufG.append(np.mean(gg)); shufC.append(np.mean(cc))

print(f"\n{'sujeto':10s} {'A sin cal':>10s} {'B calibr':>10s} {'C media':>10s} {'D oraculo':>10s} {'B vs A':>8s}")
imp=0
for s,a,bb2,c,d in rows:
    m=100*(a-bb2)/a; imp+= (bb2<a)
    print(f"{s:10s} {a:10.6f} {bb2:10.6f} {c:10.6f} {d:10.6f} {m:+7.1f}%")
R=np.array([[r[1],r[2],r[3],r[4]] for r in rows])
print(f"{'MEDIA':10s} {R[:,0].mean():10.6f} {R[:,1].mean():10.6f} {R[:,2].mean():10.6f} {R[:,3].mean():10.6f} {100*(R[:,0].mean()-R[:,1].mean())/R[:,0].mean():+7.1f}%")
print(f"sujetos con mejora: {imp}/10")

PA=np.vstack(PA_all);PB=np.vstack(PB_all);PD=np.vstack(PD_all);Y=np.vstack(Y_all)
EP=np.concatenate(EP_all);STP=np.concatenate(STP_all);GG=np.concatenate(G_all)
print("\n=== metricas agregadas sobre los 10 folds ===")
for nm,pr in [('A sin calibrar',PA),('B calibrado',PB),('D oraculo',PD)]:
    sa,_=sign_acc(pr,Y,EP,STP); r=np.mean([pearsonr(pr[:,j],Y[:,j])[0] for j in range(4)])
    print(f"  {nm:16s} MSE {mse(pr,Y):.6f} | MAE {mae(pr,Y):.4f} | r {r:+.3f} | signAcc {sa:.3f}")
print("\n  por motor (MSE):")
print(f"    {'':16s} {'M1':>9s} {'M2':>9s} {'M3':>9s} {'M4':>9s}")
for nm,pr in [('A sin calibrar',PA),('B calibrado',PB)]:
    print(f"    {nm:16s} " + " ".join(f"{mse(pr[:,j],Y[:,j]):9.6f}" for j in range(4)))
print("    motores donde B mejora a A:", sum(1 for j in range(4) if mse(PB[:,j],Y[:,j])<mse(PA[:,j],Y[:,j])),"de 4")
print("\n  por gesto (MSE):")
for q,nm in [(1,'closing'),(2,'opening')]:
    m=GG==q; print(f"    {nm:8s} A {mse(PA[m],Y[m]):.6f} | B {mse(PB[m],Y[m]):.6f} | D {mse(PD[m],Y[m]):.6f}")
mB_=R[:,1].mean()
print(f"\n=== permutaciones sobre B (3 semillas por fold) ===")
print(f"  shuffle global      MSE {np.mean(shufG):.6f}  degradacion {100*(np.mean(shufG)-mB_)/mB_:+.1f}%")
print(f"  shuffle condicionado MSE {np.mean(shufC):.6f}  degradacion {100*(np.mean(shufC)-mB_)/mB_:+.1f}%")
np.savez('e1b_detail.npz',rows=np.array(R),shufG=shufG,shufC=shufC)
