import numpy as np, sys
sys.path.insert(0,'.')
from e1b_lib import gram, solve, mse, SEED
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19); K=2; LAM=1e6
D={}
for s in DEV:
    z=np.load('shifted/%s.npz'%s); epi=z['rec']*10+z['col']; st=z['st']; o=np.lexsort((st,epi))
    D[s]=dict(Xs=z['Xs'][:,o,:], Xr=z['Xr'][:,o,:], Y=z['Y'][o], epi=epi[o], g=z['col'][o], step=st[o])
def halves2(s):
    e=np.unique(D[s]['epi']); r=np.random.default_rng(SEED+sum(map(ord,s))); p=e.copy(); r.shuffle(p); n=len(p)//2
    return set(p[:n].tolist()), set(p[n:].tolist())
H={s:halves2(s) for s in DEV}
def pidx(d,k):
    a_,b_=[],[]; bnds=np.flatnonzero(np.diff(d['epi']))+1
    for x,y in zip(np.r_[0,bnds],np.r_[bnds,len(d['epi'])]):
        L=y-x
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(x+t); b_.append(x+tt)
    return np.array(a_),np.array(b_)

print("=== 11. estabilidad del desplazamiento del oraculo (lambda 1e6, k=+2) ===")
print(f"{'sujeto':10s} {'global':>7s} {'closing':>8s} {'opening':>8s} {'M1 M2 M3 M4':>14s} {'moda ep':>8s} {'%ep con la moda':>16s}")
tabla=[]
for Sout in DEV:
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([D[t]['Xs'][0][pidx(D[t],K)[0]] for t in tr]); Ytr=np.vstack([D[t]['Y'][pidx(D[t],K)[1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); W,b=solve(A_,B_,mx,my,LAM)
    ia,ib=pidx(D[Sout],K); mm=np.isin(D[Sout]['epi'][ia],list(H[Sout][1])); Ye=D[Sout]['Y'][ib][mm]
    Pr=[D[Sout]['Xs'][r][ia][mm]@W+b for r in range(8)]
    gl=int(np.argmin([mse(p,Ye) for p in Pr]))
    gg=D[Sout]['g'][ia][mm]
    byg={q:int(np.argmin([mse(p[gg==q],Ye[gg==q]) for p in Pr])) for q in [1,2]}
    bym=[int(np.argmin([mse(p[:,j],Ye[:,j]) for p in Pr])) for j in range(4)]
    eps=D[Sout]['epi'][ia][mm]; ue=np.unique(eps)
    per=np.array([int(np.argmin([mse(p[eps==e],Ye[eps==e]) for p in Pr])) for e in ue])
    v,c=np.unique(per,return_counts=True); moda=int(v[np.argmax(c)]); frac=100*c.max()/len(per)
    print(f"{Sout:10s} {gl:7d} {byg[1]:8d} {byg[2]:8d} {str(bym):>14s} {moda:8d} {frac:15.1f}%")
    tabla.append((Sout,gl,byg[1],byg[2],bym,moda,frac))
coh_g=sum(1 for t in tabla if t[2]==t[3]); coh_m=sum(1 for t in tabla if len(set(t[4]))==1)
coh_gl=sum(1 for t in tabla if t[1]==t[5])
print(f"\n  closing y opening coinciden : {coh_g}/10")
print(f"  los 4 motores coinciden     : {coh_m}/10")
print(f"  moda por episodio == global : {coh_gl}/10")
print(f"  %episodios con la moda, media: {np.mean([t[6] for t in tabla]):.1f}%  (azar con 8 opciones = 12.5%)")

print("\n=== transferencia por mitades: .es el shift una propiedad del sujeto o ruido? ===")
print("  se elige el shift con la mitad 1 de los episodios de evaluacion y se mide en la mitad 2")
print(f"{'sujeto':10s} {'shift(m1)':>10s} {'shift(m2)':>10s} {'A en m2':>10s} {'C en m2':>10s} {'ganancia':>9s} {'oraculo m2':>11s}")
gan=[];orc=[]
for Sout in DEV:
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([D[t]['Xs'][0][pidx(D[t],K)[0]] for t in tr]); Ytr=np.vstack([D[t]['Y'][pidx(D[t],K)[1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); W,b=solve(A_,B_,mx,my,LAM)
    ia,ib=pidx(D[Sout],K); mm=np.isin(D[Sout]['epi'][ia],list(H[Sout][1]))
    eps=D[Sout]['epi'][ia][mm]; ue=np.unique(eps)
    r=np.random.default_rng(11); p=ue.copy(); r.shuffle(p); h1=set(p[:len(p)//2].tolist())
    m1=np.isin(eps,list(h1)); m2=~m1
    Ye=D[Sout]['Y'][ib][mm]
    Pr=[D[Sout]['Xs'][x][ia][mm]@W+b for x in range(8)]
    s1=int(np.argmin([mse(p[m1],Ye[m1]) for p in Pr]))
    s2=int(np.argmin([mse(p[m2],Ye[m2]) for p in Pr]))
    a2=mse(Pr[0][m2],Ye[m2]); c2=mse(Pr[s1][m2],Ye[m2]); o2=mse(Pr[s2][m2],Ye[m2])
    gan.append(100*(a2-c2)/a2); orc.append(100*(a2-o2)/a2)
    print(f"{Sout:10s} {s1:10d} {s2:10d} {a2:10.6f} {c2:10.6f} {gan[-1]:+8.1f}% {orc[-1]:+10.1f}%")
print(f"{'MEDIA':10s} {'':10s} {'':10s} {'':10s} {'':10s} {np.mean(gan):+8.1f}% {np.mean(orc):+10.1f}%")
print(f"  shift elegido en m1 == shift optimo en m2: {sum(1 for i in range(10))*0+sum(1 for x,y in zip([t for t in range(10)],[0]*10))*0}", end="")
print()
np.savez('e1c_stab.npz',gan=gan,orc=orc)
