import numpy as np, sys
sys.path.insert(0,'.')
from e1b_lib import gram, solve, mse, mae, sign_acc, SEED
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19)
g=np.load('e1c_grid.npz',allow_pickle=True); grid=g['grid']

print("=== A: el mismo (k,lambda) para ambos brazos aisla el desplazamiento ===")
A=grid[:,0]; O=grid.min(axis=1)
# config anidada del brazo A (conservadora: optima para A)
cfg=[]
for f in range(10):
    o=np.delete(A,f,axis=0).mean(0); cfg.append(np.unravel_index(np.argmin(o),o.shape))
nA=np.array([A[(f,)+cfg[f]] for f in range(10)])
nO=np.array([O[(f,)+cfg[f]] for f in range(10)])
best=np.array([int(np.argmin(grid[(f,slice(None))+cfg[f]])) for f in range(10)])
print(f"  config por fold: k={[KS[c[0]] for c in cfg]}")
print(f"                   lambda={[f'{LAMS[c[1]]:.3g}' for c in cfg]}")
print(f"  A sin alinear  MSE = {nA.mean():.6f}")
print(f"  C oraculo      MSE = {nO.mean():.6f}")
print(f"  reduccion      = {100*(nA.mean()-nO.mean())/nA.mean():+.1f}%   (umbral 15%)")
print(f"\n{'sujeto':10s} {'A':>11s} {'C oraculo':>11s} {'mejora':>8s} {'shift':>6s}")
imp=0
for f,s in enumerate(DEV):
    m=100*(nA[f]-nO[f])/nA[f]; imp+=(nO[f]<nA[f]-1e-12)
    print(f"{s:10s} {nA[f]:11.6f} {nO[f]:11.6f} {m:+7.1f}% {best[f]:6d}")
print(f"sujetos que mejoran: {imp}/10   (umbral 7/10)")
print(f"sujetos cuyo mejor shift es 0 (sin rotacion): {(best==0).sum()}/10")
np.savez('e1c_common.npz',nA=nA,nO=nO,best=best,cfg=cfg)

print("\n=== comparacion con la variante de configuracion separada por brazo ===")
def nested(gg):
    out=[]
    for f in range(gg.shape[0]):
        o=np.delete(gg,f,axis=0).mean(0); i=np.unravel_index(np.argmin(o),o.shape); out.append(gg[(f,)+i])
    return np.array(out)
print(f"  A {nested(A).mean():.6f} | C {nested(O).mean():.6f} -> {100*(nested(A).mean()-nested(O).mean())/nested(A).mean():+.1f}%")
print("  (esa cifra mezcla el efecto del desplazamiento con el de elegir otro k/lambda,")
print("   y sus conjuntos de evaluacion tienen distinto tamano al cambiar k)")
