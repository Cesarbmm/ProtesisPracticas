import numpy as np, sys
sys.path.insert(0,'.')
from e1b_lib import gram, solve, mse, mae, sign_acc, SEED
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19)
grid=np.load('e1c_grid.npz',allow_pickle=True)['grid']
A=grid[:,0]; O=grid.min(axis=1)
c=np.load('e1c_common.npz',allow_pickle=True); nA=c['nA']; nO=c['nO']; best=c['best']

print("=== .es plana la curva de lambda? (media sobre folds, k=+2, sin desplazar) ===")
ki=KS.index(2); v=A[:,ki,:].mean(0)
for li in [0,4,8,12,14,16,17,18]:
    print(f"  lambda={LAMS[li]:9.3g}  MSE medio={v[li]:.6f}")
print(f"  rango de la curva: {v.min():.6f} a {v.max():.6f}  ->  {100*(v.max()-v.min())/v.min():.1f}% de variacion")

print("\n=== robustez: lambda FIJA = 1e6 (la eleccion modal) en los 10 folds ===")
li=int(np.argmin(np.abs(LAMS-1e6)))
a=A[:,ki,li]; o=O[:,ki,li]; sh=np.array([int(np.argmin(grid[f,:,ki,li])) for f in range(10)])
print(f"{'sujeto':10s} {'A':>11s} {'C oraculo':>11s} {'mejora':>8s} {'shift':>6s}")
for f,s in enumerate(DEV):
    print(f"{s:10s} {a[f]:11.6f} {o[f]:11.6f} {100*(a[f]-o[f])/a[f]:+7.1f}% {sh[f]:6d}")
print(f"{'MEDIA':10s} {a.mean():11.6f} {o.mean():11.6f} {100*(a.mean()-o.mean())/a.mean():+7.1f}%")
print(f"  mediana de la mejora por sujeto: {np.median(100*(a-o)/a):+.1f}%")
print(f"  sujetos que mejoran: {(o<a-1e-12).sum()}/10 | shift 0: {(sh==0).sum()}/10")

print("\n=== sensibilidad a DENIS (config comun anidada) ===")
m=np.array([i for i in range(10) if DEV[i]!='DENIS'])
print(f"  con DENIS  : A {nA.mean():.6f} C {nO.mean():.6f} -> {100*(nA.mean()-nO.mean())/nA.mean():+.1f}%")
print(f"  sin DENIS  : A {nA[m].mean():.6f} C {nO[m].mean():.6f} -> {100*(nA[m].mean()-nO[m].mean())/nA[m].mean():+.1f}%")
print(f"  mediana de la mejora por sujeto (con DENIS): {np.median(100*(nA-nO)/nA):+.1f}%")

print("\n=== condicion 3: motores (lambda fija 1e6, k=+2, shift oraculo por sujeto) ===")
D={}
for s in DEV:
    z=np.load('shifted/%s.npz'%s); epi=z['rec']*10+z['col']; st=z['st']; oo=np.lexsort((st,epi))
    D[s]=dict(Xs=z['Xs'][:,oo,:], Y=z['Y'][oo], epi=epi[oo], g=z['col'][oo], step=st[oo])
def halves2(s):
    e=np.unique(D[s]['epi']); r=np.random.default_rng(SEED+sum(map(ord,s))); p=e.copy(); r.shuffle(p); n=len(p)//2
    return set(p[:n].tolist()), set(p[n:].tolist())
H={s:halves2(s) for s in DEV}
def pidx(d,k):
    a_,b_=[],[]; bnds=np.flatnonzero(np.diff(d['epi']))+1
    for x,y in zip(np.r_[0,bnds],np.r_[bnds,len(d['epi'])]):
        L=y-x
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(x+t); b_.append(x+tt)
    return np.array(a_),np.array(b_)
K=2; LAM=LAMS[li]
PA=[];PC=[];Y=[];EP=[];STP=[];GG=[]
for f,Sout in enumerate(DEV):
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([D[t]['Xs'][0][pidx(D[t],K)[0]] for t in tr]); Ytr=np.vstack([D[t]['Y'][pidx(D[t],K)[1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); W,b=solve(A_,B_,mx,my,LAM)
    ia,ib=pidx(D[Sout],K); mm=np.isin(D[Sout]['epi'][ia],list(H[Sout][1])); Ye=D[Sout]['Y'][ib][mm]
    PA.append(D[Sout]['Xs'][0][ia][mm]@W+b); PC.append(D[Sout]['Xs'][sh[f]][ia][mm]@W+b); Y.append(Ye)
    EP.append(D[Sout]['epi'][ia][mm]+f*100000); STP.append(D[Sout]['step'][ia][mm]); GG.append(D[Sout]['g'][ia][mm])
PA=np.vstack(PA);PC=np.vstack(PC);Y=np.vstack(Y);EP=np.concatenate(EP);STP=np.concatenate(STP);GG=np.concatenate(GG)
print(f"  {'':12s} {'M1':>10s} {'M2':>10s} {'M3':>10s} {'M4':>10s}")
for nm,p in [('A sin alinear',PA),('C oraculo',PC)]:
    print(f"  {nm:12s} " + " ".join(f"{mse(p[:,j],Y[:,j]):10.6f}" for j in range(4)))
mi=sum(1 for j in range(4) if mse(PC[:,j],Y[:,j])<mse(PA[:,j],Y[:,j]))
print(f"  motores que mejoran: {mi}/4   (umbral 3/4)")
sa_a,_=sign_acc(PA,Y,EP,STP); sa_c,_=sign_acc(PC,Y,EP,STP)
print(f"  sign accuracy: A {sa_a:.3f} -> C {sa_c:.3f}   |  MAE: {mae(PA,Y):.4f} -> {mae(PC,Y):.4f}")
for q,nm in [(1,'closing'),(2,'opening')]:
    z=GG==q; print(f"  {nm:8s} A {mse(PA[z],Y[z]):.6f} -> C {mse(PC[z],Y[z]):.6f}")
np.savez('e1c_final.npz',a=a,o=o,sh=sh,mi=mi,sa=[sa_a,sa_c])
