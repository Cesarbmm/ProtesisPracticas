import numpy as np, sys, time, os
sys.path.insert(0,'.')
from e1c_feat import windows_for, features_for
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
os.makedirs('shifted',exist_ok=True)
t0=time.time()
for s in DEV:
    f='shifted/%s.npz'%s
    if os.path.exists(f): continue
    wins,m=windows_for(s)
    Xs=np.stack([features_for(wins,r,False) for r in range(8)])      # (8, n, 40)
    Xr=np.stack([features_for(wins,r,True)  for r in range(8)])      # invertido (secundario)
    np.savez_compressed(f, Xs=Xs, Xr=Xr, rec=m['rec'], col=m['col'], st=m['st'],
                        Y=m['Y'], sie=m['sie'], Xexp=m['Xexp'])
    print(f"  {s:10s} listo  ({time.time()-t0:.0f}s)")
print("total %.0fs"%(time.time()-t0))
