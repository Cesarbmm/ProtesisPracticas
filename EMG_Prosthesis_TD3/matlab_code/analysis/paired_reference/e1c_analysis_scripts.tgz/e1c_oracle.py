import numpy as np, sys, time
sys.path.insert(0,'.')
from e1b_lib import halves, gram, solve, mse, mae, sign_acc, phase_table, phase_pred, NB
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
KS=[-2,-1,0,1,2]; LAMS=np.logspace(-2,7,19); NSH=8

D={}
for s in DEV:
    z=np.load('shifted/%s.npz'%s)
    epi=z['rec']*10+z['col']; st=z['st']
    o=np.lexsort((st,epi))
    D[s]=dict(Xs=z['Xs'][:,o,:], Xr=z['Xr'][:,o,:], Y=z['Y'][o], epi=epi[o],
              g=z['col'][o], step=st[o], phase=((z['st']-1)/np.maximum(z['sie']-1,1))[o])

def pairs_idx(d,k):
    """indices (i_feat, i_target) por episodio."""
    a_,b_=[],[]
    bnds=np.flatnonzero(np.diff(d['epi']))+1
    for a,b in zip(np.r_[0,bnds], np.r_[bnds,len(d['epi'])]):
        L=b-a
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(a+t); b_.append(a+tt)
    return np.array(a_),np.array(b_)

IDX={(s,k):pairs_idx(D[s],k) for s in DEV for k in KS}
H={s:halves(D,s) if False else None for s in DEV}
# halves() de e1b_lib espera S[subj]['epi']; reutilizamos su semilla exacta
from e1b_lib import SEED
def halves2(subj):
    eps=np.unique(D[subj]['epi'])
    r=np.random.default_rng(SEED + sum(map(ord,subj)))
    p=eps.copy(); r.shuffle(p); n=len(p)//2
    return set(p[:n].tolist()), set(p[n:].tolist())
H={s:halves2(s) for s in DEV}

t0=time.time()
# grid[fold, shift, k, lam] con shift=0 == brazo A
grid=np.zeros((len(DEV),NSH,len(KS),len(LAMS)))
gridR=np.zeros((len(DEV),NSH,len(KS),len(LAMS)))   # secundario: canales invertidos
for fi,Sout in enumerate(DEV):
    ev=H[Sout][1]
    tr=[t for t in DEV if t!=Sout]
    for ki,k in enumerate(KS):
        Xtr=np.vstack([D[t]['Xs'][0][IDX[(t,k)][0]] for t in tr])
        Ytr=np.vstack([D[t]['Y'][IDX[(t,k)][1]] for t in tr])
        A_,B_,mx,my=gram(Xtr,Ytr)
        ia,ib=IDX[(Sout,k)]
        m=np.isin(D[Sout]['epi'][ia], list(ev))
        Ye=D[Sout]['Y'][ib][m]
        for li,lam in enumerate(LAMS):
            W,b=solve(A_,B_,mx,my,lam)
            for r in range(NSH):
                grid[fi,r,ki,li]=mse(D[Sout]['Xs'][r][ia][m]@W+b, Ye)
                gridR[fi,r,ki,li]=mse(D[Sout]['Xr'][r][ia][m]@W+b, Ye)
    print(f"  fold {Sout:10s} ({time.time()-t0:.0f}s)")
np.savez('e1c_grid.npz',grid=grid,gridR=gridR,KS=KS,LAMS=LAMS,DEV=DEV)

def nested_sel(g):
    """g[fold, cfg...] -> valor por fold con cfg elegida sin ese fold."""
    out=[];cfg=[]
    for f in range(g.shape[0]):
        o=np.delete(g,f,axis=0).mean(0)
        i=np.unravel_index(np.argmin(o),o.shape)
        out.append(g[(f,)+i]); cfg.append(i)
    return np.array(out),cfg

A=grid[:,0]                      # (fold,k,lam) sin desplazar
O=grid.min(axis=1)               # oraculo: mejor shift por (fold,k,lam)
nA,cA=nested_sel(A); nO,cO=nested_sel(O)
print("\n=== ORACULO DE ALINEACION (CHANNEL_ALIGNMENT_ORACLE_DIAGNOSTIC_ONLY) ===")
print(f"  A sin alinear      MSE = {nA.mean():.6f}   (sd {nA.std():.6f})")
print(f"  C oraculo 8 shifts MSE = {nO.mean():.6f}   (sd {nO.std():.6f})")
print(f"  reduccion media    = {100*(nA.mean()-nO.mean())/nA.mean():+.1f}%   (umbral 15%)")
print(f"  optimista: A {A.mean(0).min():.6f} | C {O.mean(0).min():.6f} -> {100*(A.mean(0).min()-O.mean(0).min())/A.mean(0).min():+.1f}%")
np.savez('e1c_nested.npz',nA=nA,nO=nO,cA=cA,cO=cO)
