import scipy.io as sio, numpy as np, glob, os, sys
from scipy.signal import hilbert, savgol_filter
DS='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/EMG_Prosthesis_TD3/matlab_code/data/datasets/Denis Dataset/'
NV='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/EMG_Prosthesis_TD3/matlab_code/config/normValues.mat'
EXP='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/Agentes/paired_reference/stage1/export/'
_nv=sio.loadmat(NV); C=np.asarray(_nv['C']).ravel(); S=np.asarray(_nv['S']).ravel()

def wmoos_batch(W):
    """W: (n, 40, 8) ventanas de EMG. Devuelve (n,40) features normalizadas.
    Replica getWmoosFeatures: X = emg' es 8 x m y MATLAB opera por columnas."""
    X = np.transpose(W,(0,2,1))                 # (n, 8, m)
    f1 = X.std(axis=2, ddof=1)                                  # F1
    env = np.abs(hilbert(X, axis=1))                            # hilbert por el eje de canales
    aux = savgol_filter(env, 7, 1, axis=1, mode='interp')
    f2 = np.trapezoid(aux, axis=2)                              # F2
    f3 = np.abs(X).mean(axis=2)                                 # F4
    f4 = 0.5*np.abs(np.diff(X**2, axis=2)).sum(axis=2)          # F5
    f5 = np.sqrt((W**2).mean(axis=1))                           # F13 sobre emg (m x 8)
    F = np.concatenate([f1,f2,f3,f4,f5], axis=1)                # (n,40)
    return (F - C)/S

def windows_for(subj):
    """Reproduce EXACTAMENTE el troceado de RecordedMyo.readEmg(0.2):
    ventana t = filas [40(t-1) : min(40t, n)], sin relleno. La ultima puede ser parcial."""
    d=sio.loadmat(DS+subj+'.mat', struct_as_record=False, squeeze_me=True)
    emgs=d['emgs']
    e=sio.loadmat(EXP+subj+'_stage1.mat')
    rec=e['recordIdx'].ravel().astype(int); col=e['columnIdx'].ravel().astype(int)
    st=e['stepIdx'].ravel().astype(int)
    wins=[]
    for r,c,s in zip(rec,col,st):
        raw=np.asarray(emgs[r-1,c-1],dtype=float)
        n=raw.shape[0]
        a=40*(s-1); b=min(40*s, n)
        wins.append(raw[a:b,:])
    return wins, dict(rec=rec,col=col,st=st,Y=e['Y'].astype(float),
                      sie=e['stepsInEpisode'].ravel().astype(int), Xexp=e['X'].astype(float))

def features_for(wins, shift=0, reverse=False):
    """Aplica reverse/shift a la EMG cruda y calcula las 40 features, agrupando por
    longitud de ventana para poder vectorizar."""
    n=len(wins); out=np.empty((n,40))
    lens=np.array([w.shape[0] for w in wins])
    for L in np.unique(lens):
        idx=np.flatnonzero(lens==L)
        W=np.stack([wins[i] for i in idx])          # (k, L, 8)
        if reverse: W=W[:,:,::-1]
        if shift:   W=np.roll(W, shift, axis=2)
        out[idx]=wmoos_batch(W)
    return out
