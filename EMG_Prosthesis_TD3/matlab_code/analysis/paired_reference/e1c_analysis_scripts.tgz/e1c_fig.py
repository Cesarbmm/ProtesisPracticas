import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
BLUE,ORANGE,AQUA='#2a78d6','#eb6834','#1baf7a'
SURF='#fcfcfb';INK='#26251f';INK2='#5c5a50';GRID='#e3e2dc'
plt.rcParams.update({'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,
 'axes.edgecolor':GRID,'axes.labelcolor':INK2,'text.color':INK,'xtick.color':INK2,'ytick.color':INK2,
 'font.size':9,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'axes.spines.top':False,
 'axes.spines.right':False,'legend.frameon':False,'axes.axisbelow':True})
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
f=np.load('e1c_final.npz'); a=f['a']; o=f['o']; sh=f['sh']
st=np.load('e1c_stab.npz'); gan=st['gan']
SHIFTS=[[0,7,1,7,0,6,7],[3,3,7,3,0,2,7],[1,7,1,1,6,7,1],[1,5,1,1,7,0,1],[5,5,5,5,5,6,5],
        [0,4,0,0,0,6,0],[4,4,0,4,0,7,4],[0,4,0,0,1,0,0],[4,4,4,4,0,2,4],[2,3,2,6,7,2,2]]
COLS=['global','closing','opening','M1','M2','M3','M4']

fig=plt.figure(figsize=(13.5,4.4))
gs=fig.add_gridspec(1,3,width_ratios=[1.25,1.35,1.0],wspace=0.32)

ax=fig.add_subplot(gs[0]); x=np.arange(10); w=0.36
ax.bar(x-w/2,a,w,color=BLUE,label='sin alinear')
ax.bar(x+w/2,o,w,color=ORANGE,label='oraculo 8 shifts')
ax.set_xticks(x); ax.set_xticklabels(DEV,rotation=45,ha='right',fontsize=7.5)
ax.set_ylabel('MSE'); ax.legend(fontsize=8)
ax.set_title('Oraculo con lambda modal: +3.5% de media',color=INK,fontsize=10)

ax=fig.add_subplot(gs[1]); ax.grid(False)
for i,row in enumerate(SHIFTS):
    g=row[0]
    for j,v in enumerate(row):
        col=AQUA if v==g else '#efeee8'
        ax.add_patch(Rectangle((j,9-i),1,1,facecolor=col,edgecolor=SURF,lw=2))
        ax.text(j+0.5,9-i+0.5,str(v),ha='center',va='center',fontsize=8,
                color='#ffffff' if v==g else INK2)
ax.set_xlim(0,7); ax.set_ylim(0,10)
ax.set_xticks(np.arange(7)+0.5); ax.set_xticklabels(COLS,fontsize=7.5)
ax.set_yticks(np.arange(10)+0.5); ax.set_yticklabels(DEV[::-1],fontsize=7.5)
for sp in ax.spines.values(): sp.set_visible(False)
ax.set_title('Shift preferido por condicion\n(verde = coincide con el global del sujeto)',color=INK,fontsize=10)

ax=fig.add_subplot(gs[2])
ax.barh(np.arange(10),gan,0.6,color=ORANGE)
ax.axvline(15,color=INK2,lw=1.2,ls='--')
ax.text(15.4,0.2,'umbral 15%',fontsize=7.5,color=INK2,rotation=90,va='bottom')
ax.set_yticks(np.arange(10)); ax.set_yticklabels(DEV,fontsize=7.5)
ax.set_xlabel('ganancia al transferir el shift (%)'); ax.set_xlim(-2,18)
ax.set_title('Transferencia por mitades: +3.3%',color=INK,fontsize=10)
fig.suptitle('E1C · el desplazamiento de canales es estable por sujeto pero vale ~3%, no 15%',
             color=INK,fontsize=12,y=0.99)
fig.tight_layout(rect=[0,0,1,0.84]); fig.savefig('E1C_resumen.png',dpi=150)
print('ok')
