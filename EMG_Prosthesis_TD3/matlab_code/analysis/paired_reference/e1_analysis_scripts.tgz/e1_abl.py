import numpy as np, sys
sys.path.insert(0,'.')
from e1_lib import *
subs=load_all(); K=1; NB=10; LAM_X=3.16227766e5
rng=np.random.default_rng(20260904)

def shuffle_global(X,rs): 
    i=np.arange(len(X)); rs.shuffle(i); return X[i]

def shuffle_cond(X,g,phase,rs):
    """baraja solo entre muestras del mismo gesto y bin de fase"""
    Xs=X.copy(); b=np.minimum((phase*NB).astype(int),NB-1)
    for gg in np.unique(g):
        for bb in range(NB):
            m=np.flatnonzero((g==gg)&(b==bb))
            if len(m)>1:
                p=m.copy(); rs.shuffle(p); Xs[m]=X[p]
    return Xs

print("="*78)
print("B.7  CONTROLES DE PERMUTACION  (5 semillas, media)")
print("="*78)

# ---------- entre sujetos ----------
tr=build_ep(subs,SPLIT['TRAIN'],K); va=build_ep(subs,SPLIT['VALIDATION'],K)
W,b=ridge_fit(tr['X'],tr['Y'],LAM_X); base=mse(predict(W,b,va['X']),va['Y'])
mean_mse=mse(np.repeat(tr['Y'].mean(0)[None,:],len(va['Y']),axis=0),va['Y'])
gl=[];cd=[]
for sd in range(5):
    rs=np.random.default_rng(100+sd)
    W1,b1=ridge_fit(shuffle_global(tr['X'],rs),tr['Y'],LAM_X); gl.append(mse(predict(W1,b1,va['X']),va['Y']))
    W2,b2=ridge_fit(shuffle_cond(tr['X'],tr['g'],tr['phase'],rs),tr['Y'],LAM_X); cd.append(mse(predict(W2,b2,va['X']),va['Y']))
print("\n-- ENTRE SUJETOS (train 8 -> validation 2) --")
print(f"  ridge40 intacto        MSE = {base:.6f}")
print(f"  predecir la media      MSE = {mean_mse:.6f}   (ridge solo mejora {100*(mean_mse-base)/mean_mse:.1f}%)")
print(f"  ablacion 1 global      MSE = {np.mean(gl):.6f}   degradacion {100*(np.mean(gl)-base)/base:+.1f}%")
print(f"  ablacion 2 condicionada MSE = {np.mean(cd):.6f}   degradacion {100*(np.mean(cd)-base)/base:+.1f}%")
XS_G=100*(np.mean(gl)-base)/base; XS_C=100*(np.mean(cd)-base)/base

# ---------- dentro de sujeto ----------
print("\n-- DENTRO DE SUJETO (70/30 por episodios, sujetos de TRAIN) --")
print(f"  {'sujeto':10s} {'ridge':>9s} {'media':>9s} {'shufGlob':>9s} {'shufCond':>9s} {'degG':>7s} {'degC':>7s}")
rows=[]
for s in SPLIT['TRAIN']:
    d=build_ep(subs,[s],K)
    eps=np.unique(d['ep']); r2=np.random.default_rng(7); r2.shuffle(eps)
    tre=set(eps[:int(0.7*len(eps))].tolist())
    m=np.array([e in tre for e in d['ep']])
    Xtr,Ytr,Xte,Yte=d['X'][m],d['Y'][m],d['X'][~m],d['Y'][~m]
    lam=1e2
    Wb,bb=ridge_fit(Xtr,Ytr,lam); mb=mse(predict(Wb,bb,Xte),Yte)
    mm=mse(np.repeat(Ytr.mean(0)[None,:],len(Yte),axis=0),Yte)
    g1=[];c1=[]
    for sd in range(5):
        rs=np.random.default_rng(200+sd)
        W1,b1=ridge_fit(shuffle_global(Xtr,rs),Ytr,lam); g1.append(mse(predict(W1,b1,Xte),Yte))
        W2,b2=ridge_fit(shuffle_cond(Xtr,d['g'][m],d['phase'][m],rs),Ytr,lam); c1.append(mse(predict(W2,b2,Xte),Yte))
    dg=100*(np.mean(g1)-mb)/mb; dc=100*(np.mean(c1)-mb)/mb
    rows.append((mb,mm,np.mean(g1),np.mean(c1),dg,dc))
    print(f"  {s:10s} {mb:9.6f} {mm:9.6f} {np.mean(g1):9.6f} {np.mean(c1):9.6f} {dg:+6.1f}% {dc:+6.1f}%")
R=np.array(rows)
print(f"  {'MEDIA':10s} {R[:,0].mean():9.6f} {R[:,1].mean():9.6f} {R[:,2].mean():9.6f} {R[:,3].mean():9.6f} {R[:,4].mean():+6.1f}% {R[:,5].mean():+6.1f}%")
np.save('abl.npy',np.array([XS_G,XS_C,R[:,4].mean(),R[:,5].mean()]))
