import scipy.io as sio, numpy as np, glob, os
EXP='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/Agentes/paired_reference/stage1/export/'
SPLIT={'TRAIN':['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE'],
       'VALIDATION':['JONATHAN','KHAROL'],'TEST':['MATEO','SANDRA']}
data={}
for f in sorted(glob.glob(EXP+'*_stage1.mat')):
    s=os.path.basename(f).replace('_stage1.mat','')
    m=sio.loadmat(f)
    data[s]=dict(X=m['X'],Y=m['Y'],rec=m['recordIdx'].ravel(),col=m['columnIdx'].ravel(),
                 st=m['stepIdx'].ravel(),sie=m['stepsInEpisode'].ravel())

print("=== 6. perdida de muestras en los extremos por k ===")
print(f"{'k':>3s} {'TRAIN':>12s} {'VALIDATION':>12s} {'TEST':>12s} {'TOTAL':>12s} {'perdida':>9s}")
base=None
for k in [0,-1,1,-2,2]:
    per={}
    for part,subs in SPLIT.items():
        n=0
        for s in subs:
            d=data[s]
            eps=set(zip(d['rec'].tolist(),d['col'].tolist()))
            for (r,c) in eps:
                L=d['sie'][(d['rec']==r)&(d['col']==c)][0]
                n+=int(max(0,int(L)-abs(k)))
        per[part]=n
    tot=sum(per.values())
    if k==0: base=tot
    print(f"{k:3d} {per['TRAIN']:12d} {per['VALIDATION']:12d} {per['TEST']:12d} {tot:12d} {100*(base-tot)/base:8.2f}%")

print()
print("=== rango del target (flexJoined_scale) ===")
Yall=np.vstack([data[s]['Y'] for s in data])
for j in range(4):
    v=Yall[:,j]
    print(f"  motor {j+1}: min {v.min():8.4f} | p50 {np.median(v):8.4f} | max {v.max():8.4f}")
print()
print("=== phi normalizada: rango global ===")
Xall=np.vstack([data[s]['X'] for s in data])
print(f"  min {Xall.min():.3f} | p1 {np.percentile(Xall,1):.3f} | p50 {np.median(Xall):.3f} | p99 {np.percentile(Xall,99):.3f} | max {Xall.max():.3f}")
print("  NaN/Inf:", np.isnan(Xall).sum(), np.isinf(Xall).sum(), "| en Y:", np.isnan(Yall).sum(), np.isinf(Yall).sum())
print()
print("=== comprobacion registrada en 05_AUDITORIA_NORMALIZACION seccion 6 ===")
nv=sio.loadmat('/mnt/user-data/uploads/ProtesisPracticas_paired_reference/EMG_Prosthesis_TD3/matlab_code/config/normValues.mat')
C=np.asarray(nv['C']).ravel(); S=np.asarray(nv['S']).ravel()
raw=Xall*S+C
Cd=raw.mean(axis=0); Sd=raw.std(axis=0,ddof=1)
print(f"  |C_denis - C_stored| / |C_stored| : mediana {np.median(np.abs(Cd-C)/np.abs(C)):.3f}  max {np.max(np.abs(Cd-C)/np.abs(C)):.3f}")
print(f"  |S_denis - S_stored| / |S_stored| : mediana {np.median(np.abs(Sd-S)/np.abs(S)):.3f}  max {np.max(np.abs(Sd-S)/np.abs(S)):.3f}")
print(f"  C almacenado  (5 primeros): {np.round(C[:5],4)}")
print(f"  C desde Denis (5 primeros): {np.round(Cd[:5],4)}")
np.save('Xall.npy',Xall)
