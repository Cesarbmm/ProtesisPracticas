import numpy as np, sys, json
sys.path.insert(0,'.')
from e1_lib import *

subs=load_all()
KS=[-2,-1,0,1,2]
LAMS=np.logspace(-4,6,21)
NBINS=10

def baselineB_fit(tr):
    """media de y por (gesto, bin de fase) sobre TRAIN -> DIAGNOSTIC_ORACLE"""
    tbl={}
    b=np.minimum((tr['phase']*NBINS).astype(int),NBINS-1)
    for gg in [1,2]:
        for bb in range(NBINS):
            m=(tr['g']==gg)&(b==bb)
            tbl[(gg,bb)] = tr['Y'][m].mean(0) if m.sum()>0 else tr['Y'].mean(0)
    return tbl

def baselineB_pred(tbl,d):
    b=np.minimum((d['phase']*NBINS).astype(int),NBINS-1)
    return np.array([tbl[(g,bb)] for g,bb in zip(d['g'],b)])

print("="*78)
print("B.4  BASELINES  (validation, por k)")
print("="*78)
print(f"{'k':>3s} {'A_hold MSE':>12s} {'B_oracle MSE':>13s} {'A MAE':>9s} {'B MAE':>9s}")
BA={}; BB={}
for k in KS:
    tr=build_ep(subs,SPLIT['TRAIN'],k); va=build_ep(subs,SPLIT['VALIDATION'],k)
    tbl=baselineB_fit(tr)
    pa=va['yprev']; pb=baselineB_pred(tbl,va)
    BA[k]=(mse(pa,va['Y']),mae(pa,va['Y'])); BB[k]=(mse(pb,va['Y']),mae(pb,va['Y']))
    flag=" <- degenerado (y_{t-1} ES el target)" if k==-1 else ""
    print(f"{k:3d} {BA[k][0]:12.6f} {BB[k][0]:13.6f} {BA[k][1]:9.4f} {BB[k][1]:9.4f}{flag}")

print()
print("="*78)
print("B.5  RIDGE 40->4  seleccion de k y lambda SOLO con VALIDATION")
print("="*78)
res={}
best=(1e9,None,None)
for k in KS:
    tr=build_ep(subs,SPLIT['TRAIN'],k); va=build_ep(subs,SPLIT['VALIDATION'],k)
    row=[]
    for lam in LAMS:
        W,b=ridge_fit(tr['X'],tr['Y'],lam)
        m=mse(predict(W,b,va['X']),va['Y'])
        row.append(m)
        if m<best[0]: best=(m,k,lam)
    res[k]=np.array(row)
    i=int(np.argmin(row))
    print(f"  k={k:+d}  mejor lambda={LAMS[i]:10.4g}  val MSE={row[i]:.6f}   (B_oracle={BB[k][0]:.6f})")
print()
print(f"SELECCION: k={best[1]:+d}, lambda={best[2]:.6g}, validation MSE={best[0]:.6f}")
np.save('res_grid.npy',np.array([res[k] for k in KS]))
json.dump(dict(best_mse=best[0],best_k=int(best[1]),best_lam=float(best[2]),
               BA={str(k):BA[k] for k in KS}, BB={str(k):BB[k] for k in KS},
               lams=LAMS.tolist(), ks=KS), open('e1_sel.json','w'))
