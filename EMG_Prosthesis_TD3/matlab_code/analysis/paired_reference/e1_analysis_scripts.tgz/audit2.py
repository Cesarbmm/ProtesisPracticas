import scipy.io as sio, numpy as np
from scipy.signal import hilbert, savgol_filter

DS='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/EMG_Prosthesis_TD3/matlab_code/data/datasets/Denis Dataset/'
EXP='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/Agentes/paired_reference/stage1/export/'
NV='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/EMG_Prosthesis_TD3/matlab_code/config/normValues.mat'
nv=sio.loadmat(NV); C=np.asarray(nv['C']).ravel(); S=np.asarray(nv['S']).ravel()
print("C,S shapes:",C.shape,S.shape)

def wmoos(emg):
    """Replica de getWmoosFeatures sin normalizar. emg: m x 8 (double)."""
    X = emg.T                      # 8 x m
    f1 = X.std(axis=1, ddof=1)                       # WMoos_F1
    env = np.abs(hilbert(X, axis=0))                 # MATLAB hilbert -> por columnas
    aux = savgol_filter(env, 7, 1, axis=0, mode='interp')
    f2 = np.trapezoid(aux, axis=1)                       # WMoos_F2
    f3 = np.abs(X).mean(axis=1)                      # WMoos_F4
    f4 = 0.5*np.abs(np.diff(X**2, axis=1)).sum(axis=1)  # WMoos_F5
    f5 = np.sqrt((emg**2).mean(axis=0))              # WMoos_F13 sobre emg m x 8
    return np.concatenate([f1,f2,f3,f4,f5])

BLOCKS=[("F1 std",0,8),("F2 hilbert/sgolay",8,16),("F4 mav",16,24),("F5 energia",24,32),("F13 rms",32,40)]

for subj in ['BLANCA','MATEO','JONATHAN']:
    d=sio.loadmat(DS+subj+'.mat', struct_as_record=False, squeeze_me=True)
    emgs=d['emgs']
    e=sio.loadmat(EXP+subj+'_stage1.mat')
    X=e['X']; rec=e['recordIdx'].ravel(); col=e['columnIdx'].ravel(); st=e['stepIdx'].ravel()
    print(f"\n===== {subj} =====")
    print("  dtype emgs[0,0]:", np.asarray(emgs[0,0]).dtype, " shape:", np.asarray(emgs[0,0]).shape)
    errs={b[0]:[] for b in BLOCKS}
    ncheck=0
    for (r,c,step) in [(1,1,1),(1,1,3),(1,2,2),(5,1,1),(5,2,4),(20,1,2),(20,2,1),(50,1,5),(100,2,3),(200,1,1)]:
        idx=np.where((rec==r)&(col==c)&(st==step))[0]
        if len(idx)==0: continue
        raw_emg=np.asarray(emgs[r-1,c-1],dtype=float)
        a=(step-1)*40; b=step*40
        if b>raw_emg.shape[0]: continue
        win=raw_emg[a:b,:]
        phi_norm=X[idx[0]]
        phi_raw = phi_norm*S + C
        mine = wmoos(win)
        ncheck+=1
        for name,i0,i1 in BLOCKS:
            num=np.abs(mine[i0:i1]-phi_raw[i0:i1]); den=np.maximum(np.abs(phi_raw[i0:i1]),1e-12)
            errs[name].append((num/den).max())
    print(f"  ventanas verificadas: {ncheck}")
    for name,_,_ in BLOCKS:
        v=np.array(errs[name])
        print(f"    {name:20s} error relativo max = {v.max():.3e}   mediana = {np.median(v):.3e}")
