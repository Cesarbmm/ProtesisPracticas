import numpy as np, sys
sys.path.insert(0,'.')
from e1_lib import *
subs=load_all()
K=1
tr=build_ep(subs,SPLIT['TRAIN'],K); va=build_ep(subs,SPLIT['VALIDATION'],K)

print("=== 1. .colapsa el ridge a la media de train? ===")
mean_pred=np.repeat(tr['Y'].mean(0)[None,:],len(va['Y']),axis=0)
print(f"  predecir la media de TRAIN            : val MSE = {mse(mean_pred,va['Y']):.6f}")
LAMS=np.logspace(-4,9,27)
curve=[]
for lam in LAMS:
    W,b=ridge_fit(tr['X'],tr['Y'],lam)
    curve.append((lam,mse(predict(W,b,tr['X']),tr['Y']),mse(predict(W,b,va['X']),va['Y']),np.abs(W).max()))
print(f"\n  {'lambda':>10s} {'train MSE':>10s} {'val MSE':>10s} {'max|W|':>10s}")
for lam,tm,vm,w in curve:
    print(f"  {lam:10.3g} {tm:10.6f} {vm:10.6f} {w:10.4g}")

print("\n=== 2. .hay senal EMG DENTRO de un sujeto? (subject-specific) ===")
print("  train/test por episodios del MISMO sujeto, solo sujetos de TRAIN")
rng=np.random.default_rng(20260904)
print(f"  {'sujeto':10s} {'ridge MSE':>10s} {'media MSE':>10s} {'B_oracle':>10s} {'mejora %':>9s}")
gains=[]
for s in SPLIT['TRAIN']:
    d=build_ep(subs,[s],K)
    eps=np.unique(d['ep']); rng.shuffle(eps)
    ntr=int(0.7*len(eps)); tre=set(eps[:ntr].tolist())
    m=np.array([e in tre for e in d['ep']])
    Xtr,Ytr=d['X'][m],d['Y'][m]; Xte,Yte=d['X'][~m],d['Y'][~m]
    bestv=1e9
    for lam in np.logspace(-2,6,17):
        W,b=ridge_fit(Xtr,Ytr,lam)
        bestv=min(bestv,mse(predict(W,b,Xte),Yte))
    mm=mse(np.repeat(Ytr.mean(0)[None,:],len(Yte),axis=0),Yte)
    # baseline B dentro del sujeto
    NB=10; bph=np.minimum((d['phase']*NB).astype(int),NB-1)
    tbl={}
    for gg in [1,2]:
        for bb in range(NB):
            mm2=m&(d['g']==gg)&(bph==bb)
            tbl[(gg,bb)]=d['Y'][mm2].mean(0) if mm2.sum()>0 else Ytr.mean(0)
    pb=np.array([tbl[(g,bb)] for g,bb in zip(d['g'][~m],bph[~m])])
    bo=mse(pb,Yte)
    gains.append(100*(mm-bestv)/mm)
    print(f"  {s:10s} {bestv:10.6f} {mm:10.6f} {bo:10.6f} {gains[-1]:8.1f}%")
print(f"  mejora media del ridge sobre la media, dentro de sujeto: {np.mean(gains):.1f}%")

print("\n=== 3. .y entre sujetos, con lambda pequeno? ===")
for lam in [1.0, 100.0, 1e4]:
    W,b=ridge_fit(tr['X'],tr['Y'],lam)
    print(f"  lambda={lam:8.4g}  train MSE={mse(predict(W,b,tr['X']),tr['Y']):.6f}  val MSE={mse(predict(W,b,va['X']),va['Y']):.6f}")
