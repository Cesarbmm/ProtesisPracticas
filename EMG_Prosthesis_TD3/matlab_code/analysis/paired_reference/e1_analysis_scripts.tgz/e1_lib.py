import scipy.io as sio, numpy as np, glob, os
EXP='/mnt/user-data/uploads/ProtesisPracticas_paired_reference/Agentes/paired_reference/stage1/export/'
SPLIT={'TRAIN':['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE'],
       'VALIDATION':['JONATHAN','KHAROL'],'TEST':['MATEO','SANDRA']}

def load_all():
    subs={}
    for f in sorted(glob.glob(EXP+'*_stage1.mat')):
        s=os.path.basename(f).replace('_stage1.mat','')
        m=sio.loadmat(f)
        rec=m['recordIdx'].ravel().astype(int); col=m['columnIdx'].ravel().astype(int)
        st=m['stepIdx'].ravel().astype(int);   sie=m['stepsInEpisode'].ravel().astype(int)
        # id de episodio unico dentro del sujeto
        epi=rec*10+col
        subs[s]=dict(X=m['X'].astype(float), Y=m['Y'].astype(float),
                     epi=epi, gest=col, step=st, L=sie,
                     phase=(st-1)/np.maximum(sie-1,1))
    return subs

def build(subs, names, k):
    """Pares (phi_t, y_{t+k}) dentro de cada episodio."""
    Xs,Ys,G,P,E,S,Yprev,Ycur=[],[],[],[],[],[],[],[]
    for s in names:
        d=subs[s]
        order=np.lexsort((d['step'], d['epi']))
        X=d['X'][order]; Y=d['Y'][order]; epi=d['epi'][order]
        g=d['gest'][order]; ph=d['phase'][order]; st=d['step'][order]
        bnds=np.flatnonzero(np.diff(epi))+1
        for a,b in zip(np.r_[0,bnds], np.r_[bnds,len(epi)]):
            L=b-a
            for t in range(L):
                tt=t+k
                if tt<0 or tt>=L: continue
                Xs.append(X[a+t]); Ys.append(Y[a+tt]); G.append(g[a+t]); P.append(ph[a+t])
                E.append(epi[a]+hash(s)%1); S.append(s)
                Yprev.append(Y[a+t-1] if t-1>=0 else Y[a+t])   # baseline A: y_{t-1}
                Ycur.append(Y[a+t])
    return (np.array(Xs), np.array(Ys), np.array(G), np.array(P),
            np.array(S), np.array(Yprev), np.array(Ycur))

def build_ep(subs, names, k):
    """Igual que build pero devolviendo tambien un id de episodio global y el paso."""
    Xs,Ys,G,P,S,Yprev,EP,ST=[],[],[],[],[],[],[],[]
    gid=0
    for s in names:
        d=subs[s]
        order=np.lexsort((d['step'], d['epi']))
        X=d['X'][order]; Y=d['Y'][order]; epi=d['epi'][order]
        g=d['gest'][order]; ph=d['phase'][order]
        bnds=np.flatnonzero(np.diff(epi))+1
        for a,b in zip(np.r_[0,bnds], np.r_[bnds,len(epi)]):
            L=b-a; gid+=1
            for t in range(L):
                tt=t+k
                if tt<0 or tt>=L: continue
                Xs.append(X[a+t]); Ys.append(Y[a+tt]); G.append(g[a+t]); P.append(ph[a+t])
                S.append(s); EP.append(gid); ST.append(t)
                Yprev.append(Y[a+t-1] if t-1>=0 else Y[a+t])
    return dict(X=np.array(Xs), Y=np.array(Ys), g=np.array(G), phase=np.array(P),
                subj=np.array(S), yprev=np.array(Yprev), ep=np.array(EP), step=np.array(ST))

def ridge_fit(X, Y, lam):
    mx=X.mean(0); my=Y.mean(0)
    Xc=X-mx; Yc=Y-my
    A=Xc.T@Xc + lam*np.eye(X.shape[1])
    W=np.linalg.solve(A, Xc.T@Yc)
    b=my - mx@W
    return W,b

def predict(W,b,X): return X@W + b

def mse(a,b): return float(np.mean((a-b)**2))
def mae(a,b): return float(np.mean(np.abs(a-b)))

def sign_acc(pred, true, ep, step):
    """sign(delta) entre pasos consecutivos dentro del mismo episodio."""
    ok=0; n=0
    order=np.lexsort((step, ep))
    p=pred[order]; t=true[order]; e=ep[order]
    same=np.diff(e)==0
    dp=np.diff(p,axis=0)[same]; dt=np.diff(t,axis=0)[same]
    m=np.abs(dt)>1e-9
    ok=(np.sign(dp[m])==np.sign(dt[m])).sum(); n=m.sum()
    return float(ok/max(n,1)), int(n)
