import numpy as np, sys
sys.path.insert(0,'.')
from e1_lib import *
from scipy.stats import pearsonr, spearmanr
subs=load_all(); K=1

tr=build_ep(subs,SPLIT['TRAIN'],K); va=build_ep(subs,SPLIT['VALIDATION'],K)

print("=== CONTROL DE CONFOUND: estandarizacion con estadisticos SOLO de TRAIN ===")
print("  (no cambia la definicion de features ni C/S del pipeline; solo la geometria del ridge)")
mu=tr['X'].mean(0); sd=tr['X'].std(0,ddof=1); sd[sd<1e-12]=1
Ztr=(tr['X']-mu)/sd; Zva=(va['X']-mu)/sd
mean_mse=mse(np.repeat(tr['Y'].mean(0)[None,:],len(va['Y']),axis=0),va['Y'])
best=(1e9,None)
print(f"  {'lambda':>10s} {'train MSE':>10s} {'val MSE':>10s}")
for lam in np.logspace(-2,7,19):
    W,b=ridge_fit(Ztr,tr['Y'],lam)
    vm=mse(predict(W,b,Zva),va['Y'])
    if vm<best[0]: best=(vm,lam)
    if lam in [1e-2,1e0,1e2,1e3,1e4,1e5,1e6,1e7]:
        print(f"  {lam:10.3g} {mse(predict(W,b,Ztr),tr['Y']):10.6f} {vm:10.6f}")
print(f"  MEJOR: lambda={best[1]:.4g}  val MSE={best[0]:.6f}   (media de train = {mean_mse:.6f})")
print(f"  => con features estandarizados el ridge mejora {100*(mean_mse-best[0])/mean_mse:.1f}% sobre la media")

print()
print("=== METRICAS DEL MODELO SELECCIONADO (k=+1, lambda=3.162e5) EN VALIDATION ===")
LAM=3.16227766e5
W,b=ridge_fit(tr['X'],tr['Y'],LAM); P=predict(W,b,va['X']); Yv=va['Y']
NB=10
bph=np.minimum((tr['phase']*NB).astype(int),NB-1)
tbl={}
for gg in [1,2]:
    for bb in range(NB):
        m=(tr['g']==gg)&(bph==bb); tbl[(gg,bb)]=tr['Y'][m].mean(0) if m.sum() else tr['Y'].mean(0)
bv=np.minimum((va['phase']*NB).astype(int),NB-1)
PB=np.array([tbl[(g,bb)] for g,bb in zip(va['g'],bv)])
PA=va['yprev']

for name,PR in [("ridge40",P),("baseline A hold",PA),("baseline B oracle",PB)]:
    sa,n=sign_acc(PR,Yv,va['ep'],va['step'])
    pr=np.mean([pearsonr(PR[:,j],Yv[:,j])[0] for j in range(4)])
    sp=np.mean([spearmanr(PR[:,j],Yv[:,j])[0] for j in range(4)])
    print(f"  {name:20s} MSE {mse(PR,Yv):.6f} | MAE {mae(PR,Yv):.4f} | r {pr:+.3f} | rho {sp:+.3f} | signAcc {sa:.3f} (n={n})")

print()
print("  por motor (MSE):")
print(f"    {'':16s} {'M1':>9s} {'M2':>9s} {'M3':>9s} {'M4':>9s}")
for name,PR in [("ridge40",P),("baseline B",PB)]:
    v=[mse(PR[:,j],Yv[:,j]) for j in range(4)]
    print(f"    {name:16s} " + " ".join(f"{x:9.6f}" for x in v))
print("  motores donde ridge40 bate a baseline B:",
      sum(1 for j in range(4) if mse(P[:,j],Yv[:,j])<mse(PB[:,j],Yv[:,j])), "de 4")
print()
print("  por gesto (MSE):")
for gg,nm in [(1,'closing'),(2,'opening')]:
    m=va['g']==gg
    print(f"    {nm:10s} ridge40 {mse(P[m],Yv[m]):.6f} | baseline B {mse(PB[m],Yv[m]):.6f} | baseline A {mse(PA[m],Yv[m]):.6f}")
