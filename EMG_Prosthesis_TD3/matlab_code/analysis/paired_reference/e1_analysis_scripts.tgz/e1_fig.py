import numpy as np, sys, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'.')
from e1_lib import *

BLUE, ORANGE, AQUA = '#2a78d6', '#eb6834', '#1baf7a'
SURF='#fcfcfb'; INK='#26251f'; INK2='#5c5a50'; GRID='#e3e2dc'
plt.rcParams.update({'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,
    'axes.edgecolor':GRID,'axes.labelcolor':INK2,'text.color':INK,'xtick.color':INK2,
    'ytick.color':INK2,'font.size':9,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,
    'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'axes.axisbelow':True})

subs=load_all(); K=1; LAM=3.16227766e5; NB=10
tr=build_ep(subs,SPLIT['TRAIN'],K)
W,b=ridge_fit(tr['X'],tr['Y'],LAM)
bph=np.minimum((tr['phase']*NB).astype(int),NB-1)
tbl={(gg,bb): (tr['Y'][(tr['g']==gg)&(bph==bb)].mean(0) if ((tr['g']==gg)&(bph==bb)).sum() else tr['Y'].mean(0))
     for gg in [1,2] for bb in range(NB)}

# ---------------- FIGURA 1: trayectorias ----------------
fig,axes=plt.subplots(4,2,figsize=(11,10),sharex='col')
for c,s in enumerate(SPLIT['VALIDATION']):
    d=build_ep(subs,[s],K)
    eps=[]
    for gg in [1,2]:
        u=[e for e in np.unique(d['ep']) if d['g'][d['ep']==e][0]==gg][:3]
        eps+=u
    idx=np.concatenate([np.flatnonzero(d['ep']==e) for e in eps])
    Yt=d['Y'][idx]; Pr=predict(W,b,d['X'][idx])
    bv=np.minimum((d['phase'][idx]*NB).astype(int),NB-1)
    PB=np.array([tbl[(g,bb)] for g,bb in zip(d['g'][idx],bv)])
    bounds=np.cumsum([ (d['ep']==e).sum() for e in eps ])[:-1]
    x=np.arange(len(idx))
    for m in range(4):
        ax=axes[m,c]
        ax.plot(x,Yt[:,m],color=BLUE,lw=2,label='guante real' if m==0 else None)
        ax.plot(x,Pr[:,m],color=ORANGE,lw=2,label='ridge40' if m==0 else None)
        ax.plot(x,PB[:,m],color=AQUA,lw=2,ls='--',label='baseline B (oraculo)' if m==0 else None)
        for bnd in bounds: ax.axvline(bnd,color=GRID,lw=0.8)
        ax.set_ylim(-0.1,1.15); ax.set_ylabel(f'motor {m+1}' if c==0 else '')
        if m==0: ax.set_title(f'{s}   (3 closing | 3 opening)',color=INK,fontsize=10,pad=8)
        if m==3: ax.set_xlabel('paso de control (episodios concatenados)')
axes[0,0].legend(loc='upper left',fontsize=8,ncol=3,bbox_to_anchor=(0,1.34))
fig.suptitle('E1 · guante real frente a la prediccion, sujetos de VALIDATION no vistos',
             color=INK,fontsize=12,y=0.985)
fig.tight_layout(rect=[0,0,1,0.95]); fig.savefig('E1_trayectorias_validation.png',dpi=150)
print("figura 1 lista")

# ---------------- FIGURA 2: resumen ----------------
va=build_ep(subs,SPLIT['VALIDATION'],K)
P=predict(W,b,va['X']); Yv=va['Y']
bv=np.minimum((va['phase']*NB).astype(int),NB-1)
PB=np.array([tbl[(g,bb)] for g,bb in zip(va['g'],bv)]); PA=va['yprev']

fig,ax=plt.subplots(2,2,figsize=(11,7.5))
# (a) MSE por sujeto
subsv=SPLIT['VALIDATION']; w=0.35; xs=np.arange(len(subsv))
r=[mse(P[va['subj']==s],Yv[va['subj']==s]) for s in subsv]
bb_=[mse(PB[va['subj']==s],Yv[va['subj']==s]) for s in subsv]
ax[0,0].bar(xs-w/2,r,w,color=ORANGE,label='ridge40')
ax[0,0].bar(xs+w/2,bb_,w,color=AQUA,label='baseline B (oraculo)')
ax[0,0].set_xticks(xs); ax[0,0].set_xticklabels(subsv); ax[0,0].set_ylabel('MSE')
ax[0,0].set_title('MSE por sujeto de validation',color=INK,fontsize=10); ax[0,0].legend(fontsize=8)
# (b) MSE por motor
xm=np.arange(4)
ax[0,1].bar(xm-w/2,[mse(P[:,j],Yv[:,j]) for j in range(4)],w,color=ORANGE,label='ridge40')
ax[0,1].bar(xm+w/2,[mse(PB[:,j],Yv[:,j]) for j in range(4)],w,color=AQUA,label='baseline B')
ax[0,1].set_xticks(xm); ax[0,1].set_xticklabels([f'M{j+1}' for j in range(4)])
ax[0,1].set_ylabel('MSE'); ax[0,1].set_title('MSE por motor (0 de 4 a favor del ridge)',color=INK,fontsize=10)
ax[0,1].legend(fontsize=8)
# (c) sign accuracy
names=['ridge40','baseline B','baseline A']; vals=[sign_acc(x,Yv,va['ep'],va['step'])[0] for x in [P,PB,PA]]
ax[1,0].bar(np.arange(3),vals,0.55,color=[ORANGE,AQUA,BLUE])
ax[1,0].axhline(0.5,color=INK2,lw=1,ls=':'); ax[1,0].set_ylim(0,1)
ax[1,0].set_xticks(np.arange(3)); ax[1,0].set_xticklabels(names,fontsize=8)
ax[1,0].set_ylabel('sign accuracy de dy'); ax[1,0].set_title('Direccion del movimiento (0.5 = azar)',color=INK,fontsize=10)
# (d) ablaciones
abl=np.load('abl.npy')  # [xs_glob, xs_cond, in_glob, in_cond]
labels=['global\nentre sujetos','condicionada\nentre sujetos','global\ndentro de sujeto','condicionada\ndentro de sujeto']
cols=[BLUE,BLUE,ORANGE,ORANGE]
ax[1,1].bar(np.arange(4),abl,0.55,color=cols)
ax[1,1].axhline(0,color=INK2,lw=1)
ax[1,1].set_xticks(np.arange(4)); ax[1,1].set_xticklabels(labels,fontsize=7.5)
ax[1,1].set_ylabel('degradacion del MSE al barajar EMG (%)')
ax[1,1].set_title('Controles de permutacion',color=INK,fontsize=10)
fig.suptitle('E1 · resumen: el ridge no bate a los baselines en sujetos no vistos',color=INK,fontsize=12)
fig.tight_layout(rect=[0,0,1,0.95]); fig.savefig('E1_resumen.png',dpi=150)
print("figura 2 lista")
