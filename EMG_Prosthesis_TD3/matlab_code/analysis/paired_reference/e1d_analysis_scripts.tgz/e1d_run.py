import numpy as np, sys, time
sys.path.insert(0,'.')
from e1b_lib import load_raw, halves, cal_eps, gram, solve, mse, mae, sign_acc, SEED, NB, phase_table, phase_pred
from scipy.stats import pearsonr, spearmanr
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
K=2; LAM_G=1e6; BUD=[1,2,5,10,20]; BUD_DIAG=50
LP=np.logspace(-2,8,21)          # lambda_personal
S=load_raw(); H={s:halves(S,s) for s in DEV}

def pidx(d,k):
    a_,b_=[],[]; bnds=np.flatnonzero(np.diff(d['epi']))+1
    for x,y in zip(np.r_[0,bnds],np.r_[bnds,len(d['epi'])]):
        L=y-x
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(x+t); b_.append(x+tt)
    return np.array(a_),np.array(b_)
P={s:pidx(S[s],K) for s in DEV}

def slice_by_eps(s, keep):
    ia,ib=P[s]; m=np.isin(S[s]['epi'][ia], list(keep))
    return dict(X=S[s]['X'][ia][m], Y=S[s]['Y'][ib][m], g=S[s]['g'][ia][m],
                phase=S[s]['phase'][ia][m], ep=S[s]['epi'][ia][m], step=S[s]['step'][ia][m])

def personalized(Xc_,Yc_,Wg,lp):
    mx=Xc_.mean(0); my=Yc_.mean(0); Xc=Xc_-mx; Yc=Yc_-my
    W=np.linalg.solve(Xc.T@Xc + lp*np.eye(40), Xc.T@Yc + lp*Wg)
    return W, my-mx@W

t0=time.time()
GW={}   # ridge global por fold
EVAL={s:slice_by_eps(s,H[s][1]) for s in DEV}
for f,Sout in enumerate(DEV):
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([S[t]['X'][P[t][0]] for t in tr]); Ytr=np.vstack([S[t]['Y'][P[t][1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); GW[Sout]=solve(A_,B_,mx,my,LAM_G)+(Ytr.mean(0),)
    # tabla gesto+fase del train
    dtr={'g':np.concatenate([S[t]['g'][P[t][0]] for t in tr]),
         'phase':np.concatenate([S[t]['phase'][P[t][0]] for t in tr]), 'Y':Ytr}
    GW[Sout]=GW[Sout]+(phase_table(dtr),)
print(f"ridges globales listos ({time.time()-t0:.0f}s)")

CAL={(s,N):cal_eps(S,s,N,H[s][0]) for s in DEV for N in BUD+[BUD_DIAG]}
res={}   # (arm,N,fold) -> mse ; y grid para lambda_personal
gridC=np.zeros((len(DEV),len(BUD)+1,len(LP)))
base={}
for f,Sout in enumerate(DEV):
    Wg,bg,Ymean_tr,tbl=GW[Sout]
    ev=EVAL[Sout]
    pA=ev['X']@Wg+bg
    base[(Sout,'A')]=mse(pA,ev['Y'])
    base[(Sout,'meanTr')]=mse(np.repeat(Ymean_tr[None,:],len(ev['Y']),0),ev['Y'])
    base[(Sout,'D')]=mse(phase_pred(tbl,ev),ev['Y'])
    for bi,N in enumerate(BUD+[BUD_DIAG]):
        cal=slice_by_eps(Sout,CAL[(Sout,N)])
        base[(Sout,'meanCal',N)]=mse(np.repeat(cal['Y'].mean(0)[None,:],len(ev['Y']),0),ev['Y'])
        # A': global + intercepto del sujeto
        bAp=cal['Y'].mean(0)-cal['X'].mean(0)@Wg
        base[(Sout,"A'",N)]=mse(ev['X']@Wg+bAp,ev['Y'])
        # B: subject-only ridge (lambda por CV anidada mas abajo; aqui malla)
        bB=[]
        for lp in LP:
            Ab,Bb,mxb,myb=gram(cal['X'],cal['Y']); Wb,bb=solve(Ab,Bb,mxb,myb,lp)
            bB.append(mse(ev['X']@Wb+bb,ev['Y']))
        base[(Sout,'Bgrid',N)]=np.array(bB)
        # C: personalizado regularizado hacia W_global
        for li,lp in enumerate(LP):
            W,b=personalized(cal['X'],cal['Y'],Wg,lp)
            gridC[f,bi,li]=mse(ev['X']@W+b,ev['Y'])
print(f"rejilla completa ({time.time()-t0:.0f}s)")
np.savez('e1d_grid.npz',gridC=gridC,LP=LP,BUD=BUD+[BUD_DIAG],DEV=DEV)
import pickle; pickle.dump(base,open('e1d_base.pkl','wb'))

print("\n=== curva por presupuesto (CV ANIDADA sobre lambda_personal) ===")
print(f"{'N/gesto':>8s} {'ep':>4s} {'seg':>7s} {'A global':>10s} {'meanCal':>9s} {'B solo':>9s} {'C person':>9s} {'C vs A':>8s} {'C vs mean':>10s}")
def nested_pick(g):     # g[fold, lam] -> valor por fold con lam elegida sin ese fold
    out=[];pick=[]
    for f in range(g.shape[0]):
        o=np.delete(g,f,axis=0).mean(0); i=int(np.argmin(o)); out.append(g[f,i]); pick.append(i)
    return np.array(out),pick
summary={}
for bi,N in enumerate(BUD+[BUD_DIAG]):
    A=np.array([base[(s,'A')] for s in DEV])
    mc=np.array([base[(s,'meanCal',N)] for s in DEV])
    Bg=np.stack([base[(s,'Bgrid',N)] for s in DEV]); nB,_=nested_pick(Bg)
    nC,pick=nested_pick(gridC[:,bi,:])
    summary[N]=dict(A=A,mc=mc,nB=nB,nC=nC,pick=pick)
    tag=" (diagnostico, >5 min)" if N==BUD_DIAG else ""
    print(f"{N:8d} {2*N:4d} {2*N*3.05:7.1f} {A.mean():10.6f} {mc.mean():9.6f} {nB.mean():9.6f} {nC.mean():9.6f} "
          f"{100*(A.mean()-nC.mean())/A.mean():+7.1f}% {100*(mc.mean()-nC.mean())/mc.mean():+9.1f}%{tag}")
import pickle as pk; pk.dump(summary,open('e1d_summary.pkl','wb'))
print(f"\n  referencia: media de train {np.mean([base[(s,'meanTr')] for s in DEV]):.6f} | "
      f"D gesto+fase {np.mean([base[(s,'D')] for s in DEV]):.6f}")
