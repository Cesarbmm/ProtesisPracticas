import numpy as np, sys, pickle
sys.path.insert(0,'.')
from e1b_lib import load_raw, halves, cal_eps, gram, solve, mse, mae, sign_acc, SEED, NB, phase_table, phase_pred
from scipy.stats import pearsonr, spearmanr
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
K=2; LAM_G=1e6; BUD=[1,2,5,10,20]; ALL=BUD+[50]
g=np.load('e1d_grid.npz',allow_pickle=True); gridC=g['gridC']; LP=g['LP']
base=pickle.load(open('e1d_base.pkl','rb'))
S=load_raw(); H={s:halves(S,s) for s in DEV}
def pidx(d,k):
    a_,b_=[],[]; bnds=np.flatnonzero(np.diff(d['epi']))+1
    for x,y in zip(np.r_[0,bnds],np.r_[bnds,len(d['epi'])]):
        L=y-x
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(x+t); b_.append(x+tt)
    return np.array(a_),np.array(b_)
P={s:pidx(S[s],K) for s in DEV}
def sl(s,keep):
    ia,ib=P[s]; m=np.isin(S[s]['epi'][ia],list(keep))
    return dict(X=S[s]['X'][ia][m],Y=S[s]['Y'][ib][m],g=S[s]['g'][ia][m],
                phase=S[s]['phase'][ia][m],ep=S[s]['epi'][ia][m],step=S[s]['step'][ia][m])
def pers(Xc_,Yc_,Wg,lp):
    mx=Xc_.mean(0);my=Yc_.mean(0);Xc=Xc_-mx;Yc=Yc_-my
    W=np.linalg.solve(Xc.T@Xc+lp*np.eye(40), Xc.T@Yc+lp*Wg); return W,my-mx@W

# --- seleccion anidada CONJUNTA de (presupuesto, lambda_p), solo presupuestos <= 5 min
GB=gridC[:,:len(BUD),:]                      # (fold, budget, lam)
sel=[]; nested=[]
for f in range(10):
    o=np.delete(GB,f,axis=0).mean(0); i=np.unravel_index(np.argmin(o),o.shape)
    sel.append(i); nested.append(GB[(f,)+i])
nested=np.array(nested)
print("=== seleccion anidada conjunta (presupuesto y lambda_personal) ===")
print(f"  presupuesto elegido por fold: {[BUD[i[0]] for i in sel]}")
print(f"  lambda_p elegida por fold   : {[f'{LP[i[1]]:.3g}' for i in sel]}")
A=np.array([base[(s,'A')] for s in DEV])
print(f"  A global   {A.mean():.6f}")
print(f"  C anidado  {nested.mean():.6f}   -> {100*(A.mean()-nested.mean())/A.mean():+.1f}% vs A")

# --- detalle con el presupuesto modal
NB_=BUD[int(np.bincount([i[0] for i in sel]).argmax())]
bi=BUD.index(NB_)
print(f"\n=== detalle con el presupuesto modal N={NB_} ({2*NB_} episodios, {2*NB_*3.05:.1f} s) ===")
lp_pick=[]
for f in range(10):
    o=np.delete(gridC[:,bi,:],f,axis=0).mean(0); lp_pick.append(int(np.argmin(o)))
PA=[];PC=[];Y=[];EP=[];ST=[];GG=[];rows=[];PD=[]
c1=[];c2=[]
for f,Sout in enumerate(DEV):
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([S[t]['X'][P[t][0]] for t in tr]); Ytr=np.vstack([S[t]['Y'][P[t][1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); Wg,bg=solve(A_,B_,mx,my,LAM_G)
    dtr={'g':np.concatenate([S[t]['g'][P[t][0]] for t in tr]),
         'phase':np.concatenate([S[t]['phase'][P[t][0]] for t in tr]),'Y':Ytr}
    tbl=phase_table(dtr)
    ev=sl(Sout,H[Sout][1]); cal=sl(Sout,cal_eps(S,Sout,NB_,H[Sout][0]))
    lp=LP[lp_pick[f]]
    W,b=pers(cal['X'],cal['Y'],Wg,lp)
    pa=ev['X']@Wg+bg; pc=ev['X']@W+b
    rows.append((Sout,mse(pa,ev['Y']),mse(pc,ev['Y']),base[(Sout,'meanCal',NB_)],base[(Sout,"A'",NB_)]))
    PA.append(pa);PC.append(pc);PD.append(phase_pred(tbl,ev));Y.append(ev['Y'])
    EP.append(ev['ep']+f*100000);ST.append(ev['step']);GG.append(ev['g'])
    # controles sobre la calibracion
    g1=[];g2=[]
    for sd in range(5):
        r=np.random.default_rng(900+sd)
        # C1: barajar targets entre episodios de calibracion
        ue=np.unique(cal['ep']); perm=ue.copy(); r.shuffle(perm)
        mp={a:bb for a,bb in zip(ue,perm)}
        Ys=np.vstack([cal['Y'][cal['ep']==mp[e]][:(cal['ep']==e).sum()] if (cal['ep']==mp[e]).sum()>=(cal['ep']==e).sum()
                      else np.resize(cal['Y'][cal['ep']==mp[e]],((cal['ep']==e).sum(),4)) for e in ue])
        idx=np.concatenate([np.flatnonzero(cal['ep']==e) for e in ue])
        Yc1=np.empty_like(cal['Y']); Yc1[idx]=Ys
        W1,b1=pers(cal['X'],Yc1,Wg,lp); g1.append(mse(ev['X']@W1+b1,ev['Y']))
        # C2: barajar emparejamiento dentro del mismo gesto y bin de fase
        Yc2=cal['Y'].copy(); bph=np.minimum((cal['phase']*NB).astype(int),NB-1)
        for q in [1,2]:
            for bb in range(NB):
                m=np.flatnonzero((cal['g']==q)&(bph==bb))
                if len(m)>1:
                    pp=m.copy(); r.shuffle(pp); Yc2[m]=cal['Y'][pp]
        W2,b2=pers(cal['X'],Yc2,Wg,lp); g2.append(mse(ev['X']@W2+b2,ev['Y']))
    c1.append(np.mean(g1)); c2.append(np.mean(g2))

print(f"{'sujeto':10s} {'A global':>10s} {'A+intercep':>11s} {'meanCal':>9s} {'C person':>9s} {'C vs A':>8s}")
imp=0
for (s,a,c,mc,ap) in rows:
    imp+=(c<a); print(f"{s:10s} {a:10.6f} {ap:11.6f} {mc:9.6f} {c:9.6f} {100*(a-c)/a:+7.1f}%")
R=np.array([[r[1],r[2],r[3],r[4]] for r in rows])
print(f"{'MEDIA':10s} {R[:,0].mean():10.6f} {R[:,3].mean():11.6f} {R[:,2].mean():9.6f} {R[:,1].mean():9.6f} "
      f"{100*(R[:,0].mean()-R[:,1].mean())/R[:,0].mean():+7.1f}%")
print(f"{'MEDIANA':10s} {'':10s} {'':11s} {'':9s} {'':9s} {np.median(100*(R[:,0]-R[:,1])/R[:,0]):+7.1f}%")
print(f"  sujetos que mejoran: {imp}/10 (umbral 8/10) | sd entre sujetos: A {R[:,0].std():.6f} C {R[:,1].std():.6f}")
print(f"  vs A+intercepto: {100*(R[:,3].mean()-R[:,1].mean())/R[:,3].mean():+.1f}%  <- cuanto aporta C mas alla del offset")

PA=np.vstack(PA);PC=np.vstack(PC);PD=np.vstack(PD);Y=np.vstack(Y)
EP=np.concatenate(EP);ST=np.concatenate(ST);GG=np.concatenate(GG)
print("\n=== metricas agregadas ===")
for nm,p in [('A global',PA),('C personalizado',PC),('D gesto+fase',PD)]:
    sa,_=sign_acc(p,Y,EP,ST); r=np.mean([pearsonr(p[:,j],Y[:,j])[0] for j in range(4)])
    rho=np.mean([spearmanr(p[:,j],Y[:,j])[0] for j in range(4)])
    print(f"  {nm:16s} MSE {mse(p,Y):.6f} | MAE {mae(p,Y):.4f} | r {r:+.3f} | rho {rho:+.3f} | signAcc {sa:.3f}")
print("\n  por motor (MSE):")
print(f"    {'':16s} {'M1':>10s} {'M2':>10s} {'M3':>10s} {'M4':>10s}")
for nm,p in [('A global',PA),('C personalizado',PC)]:
    print(f"    {nm:16s} " + " ".join(f"{mse(p[:,j],Y[:,j]):10.6f}" for j in range(4)))
mi=sum(1 for j in range(4) if mse(PC[:,j],Y[:,j])<mse(PA[:,j],Y[:,j]))
print(f"    motores que mejoran: {mi}/4 (umbral 3/4)")
for q,nm in [(1,'closing'),(2,'opening')]:
    m=GG==q; print(f"  {nm:8s} A {mse(PA[m],Y[m]):.6f} -> C {mse(PC[m],Y[m]):.6f}")
mC=R[:,1].mean()
print(f"\n=== controles de informacion (5 semillas) ===")
print(f"  CONTROL 1 targets barajados    MSE {np.mean(c1):.6f}  degradacion {100*(np.mean(c1)-mC)/mC:+.1f}%  (umbral 15%)")
print(f"  CONTROL 2 condicionado         MSE {np.mean(c2):.6f}  degradacion {100*(np.mean(c2)-mC)/mC:+.1f}%  (umbral 5%)")
np.savez('e1d_detail.npz',R=R,c1=c1,c2=c2,nested=nested,NB=NB_,mi=mi,imp=imp)
