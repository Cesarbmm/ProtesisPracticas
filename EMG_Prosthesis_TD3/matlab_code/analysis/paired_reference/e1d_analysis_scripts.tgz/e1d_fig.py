import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
BLUE,ORANGE,AQUA='#2a78d6','#eb6834','#1baf7a'
SURF='#fcfcfb';INK='#26251f';INK2='#5c5a50';GRID='#e3e2dc'
plt.rcParams.update({'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,
 'axes.edgecolor':GRID,'axes.labelcolor':INK2,'text.color':INK,'xtick.color':INK2,'ytick.color':INK2,
 'font.size':9,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'axes.spines.top':False,
 'axes.spines.right':False,'legend.frameon':False,'axes.axisbelow':True})
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
d=np.load('e1d_detail.npz'); R=d['R']
f=np.load('e1d_final.npz'); c1=f['c1']; c2=f['c2']; mC=float(f['mC'])
secs=[6.1,12.2,30.5,61.0,122.0,305.0]
A=[0.040639]*6; mc=[0.039063,0.039417,0.039552,0.039963,0.040368,0.039129]
B=[0.034423,0.034743,0.034312,0.033054,0.034497,0.031570]
C=[0.034184,0.034432,0.033935,0.032608,0.034070,0.031467]
Dor=0.018365

fig,ax=plt.subplots(1,3,figsize=(13.5,4.3),gridspec_kw={'width_ratios':[1.15,1.35,0.85]})
ax[0].plot(secs,A,color=INK2,lw=2,ls=':',label='A ridge global')
ax[0].plot(secs,mc,color=AQUA,lw=2,ls='--',label='media de calibracion')
ax[0].plot(secs,B,color=BLUE,lw=2,marker='o',ms=6,label='B solo del sujeto')
ax[0].plot(secs,C,color=ORANGE,lw=2,marker='o',ms=7,label='C personalizado')
ax[0].axhline(Dor,color=INK2,lw=1.2)
ax[0].text(150,Dor+0.0012,'D gesto+fase (oraculo)',fontsize=7.5,color=INK2)
ax[0].axvline(300,color=GRID,lw=1)
ax[0].set_xlabel('EMG de calibracion (s)'); ax[0].set_ylabel('MSE'); ax[0].set_ylim(0.015,0.043)
ax[0].legend(fontsize=8); ax[0].set_title('Curva de presupuesto: plana y lejos del oraculo',color=INK,fontsize=10)

x=np.arange(10); w=0.38
ax[1].bar(x-w/2,R[:,0],w,color=BLUE,label='A ridge global')
ax[1].bar(x+w/2,R[:,1],w,color=ORANGE,label='C personalizado (N=5, 30.5 s)')
ax[1].set_xticks(x); ax[1].set_xticklabels(DEV,rotation=45,ha='right',fontsize=7.5)
ax[1].set_ylabel('MSE'); ax[1].legend(fontsize=8)
ax[1].set_title('7 de 10 sujetos mejoran; dos empeoran claramente',color=INK,fontsize=10)

vals=[100*(np.mean(c1)-mC)/mC, 100*(np.mean(c2)-mC)/mC]
ax[2].bar([0,1],vals,0.5,color=[BLUE,ORANGE])
ax[2].axhline(15,color=INK2,lw=1.2,ls='--'); ax[2].axhline(5,color=INK2,lw=1,ls=':')
ax[2].text(1.45,15.3,'umbral 15%',fontsize=7.5,color=INK2,ha='right')
ax[2].text(1.45,5.3,'umbral 5%',fontsize=7.5,color=INK2,ha='right')
ax[2].set_xticks([0,1]); ax[2].set_xticklabels(['CONTROL 1\ntrayectoria de\notro episodio','CONTROL 2\ncondicionado\ngesto+fase'],fontsize=7.5)
ax[2].set_ylim(0,18); ax[2].set_xlim(-0.6,1.6)
ax[2].set_ylabel('degradacion del MSE (%)')
ax[2].set_title('Controles: el decoder no lee EMG',color=INK,fontsize=10)
fig.suptitle('E1D · la calibracion supervisada mejora, pero lo que aprende es gesto+fase, no EMG',
             color=INK,fontsize=12,y=0.99)
fig.tight_layout(rect=[0,0,1,0.9]); fig.savefig('E1D_resumen.png',dpi=150)
print('ok')
