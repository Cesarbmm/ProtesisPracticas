import numpy as np, sys, pickle
sys.path.insert(0,'.')
from e1b_lib import load_raw, halves, cal_eps, gram, solve, mse, sign_acc, NB
DEV=['BLANCA','CECILIA','DENIS','EMILIA','GABI','GABRIEL','IVANNA','JOE','JONATHAN','KHAROL']
K=2; LAM_G=1e6; BUD=[1,2,5,10,20]
g=np.load('e1d_grid.npz',allow_pickle=True); gridC=g['gridC']; LP=g['LP']
base=pickle.load(open('e1d_base.pkl','rb'))
S=load_raw(); H={s:halves(S,s) for s in DEV}
def pidx(d,k):
    a_,b_=[],[]; bnds=np.flatnonzero(np.diff(d['epi']))+1
    for x,y in zip(np.r_[0,bnds],np.r_[bnds,len(d['epi'])]):
        L=y-x
        for t in range(L):
            tt=t+k
            if 0<=tt<L: a_.append(x+t); b_.append(x+tt)
    return np.array(a_),np.array(b_)
P={s:pidx(S[s],K) for s in DEV}
def sl(s,keep):
    ia,ib=P[s]; m=np.isin(S[s]['epi'][ia],list(keep))
    return dict(X=S[s]['X'][ia][m],Y=S[s]['Y'][ib][m],g=S[s]['g'][ia][m],
                phase=S[s]['phase'][ia][m],ep=S[s]['epi'][ia][m])
def pers(Xc_,Yc_,Wg,lp):
    mx=Xc_.mean(0);my=Yc_.mean(0);Xc=Xc_-mx;Yc=Yc_-my
    return np.linalg.solve(Xc.T@Xc+lp*np.eye(40),Xc.T@Yc+lp*Wg), None
GB=gridC[:,:len(BUD),:]
sel=[];nested=[]
for f in range(10):
    o=np.delete(GB,f,axis=0).mean(0); i=np.unravel_index(np.argmin(o),o.shape)
    sel.append(i); nested.append(GB[(f,)+i])
nested=np.array(nested)
A=np.array([base[(s,'A')] for s in DEV])
mcs=np.array([base[(s,'meanCal',BUD[sel[f][0]])] for f,s in enumerate(DEV)])
mtr=np.array([base[(s,'meanTr')] for s in DEV])
print("=== NUMEROS ANIDADOS (presupuesto y lambda_p elegidos sin el fold reportado) ===")
print(f"  A global ridge        {A.mean():.6f}")
print(f"  C personalizado       {nested.mean():.6f}")
print(f"  mejora vs A           {100*(A.mean()-nested.mean())/A.mean():+.1f}%   (umbral 20%)")
print(f"  media de calibracion  {mcs.mean():.6f}  -> mejora {100*(mcs.mean()-nested.mean())/mcs.mean():+.1f}%  (umbral 15%)")
print(f"  media de train        {mtr.mean():.6f}  -> mejora {100*(mtr.mean()-nested.mean())/mtr.mean():+.1f}%")
print(f"  sujetos que mejoran (anidado): {(nested<A).sum()}/10")
print(f"  mediana de la mejora: {np.median(100*(A-nested)/A):+.1f}%")

print("\n=== CONTROL 1 mejorado: cada episodio de calibracion recibe la trayectoria de OTRO episodio")
print("    del mismo gesto, remuestreada por fase ===")
NB_=5; bi=BUD.index(NB_)
lp_pick=[int(np.argmin(np.delete(gridC[:,bi,:],f,axis=0).mean(0))) for f in range(10)]
c1=[];c2=[];mC=[]
for f,Sout in enumerate(DEV):
    tr=[t for t in DEV if t!=Sout]
    Xtr=np.vstack([S[t]['X'][P[t][0]] for t in tr]); Ytr=np.vstack([S[t]['Y'][P[t][1]] for t in tr])
    A_,B_,mx,my=gram(Xtr,Ytr); Wg,bg=solve(A_,B_,mx,my,LAM_G)
    ev=sl(Sout,H[Sout][1]); cal=sl(Sout,cal_eps(S,Sout,NB_,H[Sout][0])); lp=LP[lp_pick[f]]
    W,_=pers(cal['X'],cal['Y'],Wg,lp); b=cal['Y'].mean(0)-cal['X'].mean(0)@W
    mC.append(mse(ev['X']@W+b,ev['Y']))
    g1=[];g2=[]
    for sd in range(5):
        r=np.random.default_rng(1300+sd)
        Yc=cal['Y'].copy()
        for q in [1,2]:
            ue=np.array(sorted({int(e) for e in cal['ep'][cal['g']==q]}))
            if len(ue)<2: continue
            perm=ue.copy(); r.shuffle(perm)
            for e,e2 in zip(ue,perm):
                mi=np.flatnonzero(cal['ep']==e); mj=np.flatnonzero(cal['ep']==e2)
                ph_i=cal['phase'][mi]; ph_j=cal['phase'][mj]
                idx=np.argmin(np.abs(ph_i[:,None]-ph_j[None,:]),axis=1)
                Yc[mi]=cal['Y'][mj][idx]
        W1,_=pers(cal['X'],Yc,Wg,lp); b1=Yc.mean(0)-cal['X'].mean(0)@W1
        g1.append(mse(ev['X']@W1+b1,ev['Y']))
        Yc2=cal['Y'].copy(); bph=np.minimum((cal['phase']*NB).astype(int),NB-1)
        for q in [1,2]:
            for bb in range(NB):
                m=np.flatnonzero((cal['g']==q)&(bph==bb))
                if len(m)>1:
                    pp=m.copy(); r.shuffle(pp); Yc2[m]=cal['Y'][pp]
        W2,_=pers(cal['X'],Yc2,Wg,lp); b2=Yc2.mean(0)-cal['X'].mean(0)@W2
        g2.append(mse(ev['X']@W2+b2,ev['Y']))
    c1.append(np.mean(g1)); c2.append(np.mean(g2))
mC=np.mean(mC)
print(f"  C personalizado (N=5)            {mC:.6f}")
print(f"  CONTROL 1 trayectoria de otro ep {np.mean(c1):.6f}   degradacion {100*(np.mean(c1)-mC)/mC:+.1f}%  (umbral 15%)")
print(f"  CONTROL 2 condicionado gesto+fase{np.mean(c2):.6f}   degradacion {100*(np.mean(c2)-mC)/mC:+.1f}%  (umbral 5%)")
np.savez('e1d_final.npz',nested=nested,A=A,mcs=mcs,c1=c1,c2=c2,mC=mC,sel=np.array(sel))
